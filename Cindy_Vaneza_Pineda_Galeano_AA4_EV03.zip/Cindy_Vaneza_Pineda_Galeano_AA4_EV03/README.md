# Componente front-end del CRM de fidelización de clientes MEDELED
**Evidencia:** GA7-220501096-AA4-EV03  
**Aprendiz:** Cindy Vaneza Pineda Galeano  
**Programa:** Tecnología en Análisis y Desarrollo de Software, SENA  
**Ficha:** 3336209

## Empezar
1. Descomprime la carpeta completa.
2. Para revisar la demostración sin instalar dependencias, abre `ABRIR_DEMO.html` con Chrome o Edge. Si el navegador impide el almacenamiento desde un archivo, utiliza el procedimiento siguiente.
3. Para desarrollar, ejecutar pruebas o conectarte a la API, instala Node.js 22.12 o superior. Se utilizó Node 24.22.1.
4. Abre una terminal en `proyecto` y ejecuta:
```sh
npm ci
npm run dev
```
5. Abre la dirección que aparece en la terminal, normalmente `http://127.0.0.1:5173`.
En Windows también puedes ejecutar `INICIAR_WINDOWS.bat` después de instalar Node.js.

## Qué contiene
- Front-end React con componentes funcionales, JSX y CSS adaptable.
- Registro, consulta, edición y desactivación de clientes; filtro y paginación.
- Registro de ventas, historial por cliente y descarga CSV con datos de contacto actuales.
- Seguimiento con fecha, canal, responsable, resultado y expectativa acordada.
- PQRS con radicado, estados e historial de gestión.
- Inventario local con fecha obligatoria y etiqueta morada durante dos meses calendario.
- Panel con indicadores calculados, alertas azules/rojas y reportes.
- Pantalla `Conexión API` con CRUD de clientes/reclamos y ventas compatible con el contrato del repositorio.
- Pruebas, comentarios, formato automático y registro de versiones Git.

## Dos orígenes de datos separados
**Demostración:** guarda datos ficticios en localStorage del navegador. Ningún SQL se ejecuta y no se modifica MySQL. Los cambios de un navegador no aparecen en otro. La descarga de respaldo genera un JSON; no existe importación automática ni recuperación desde el servidor. No ingreses información sensible en esta demostración.

**Conexión API:** consulta y modifica exclusivamente el servidor indicado al presionar `Consultar servidor`. Requiere que la API Java del grupo esté ejecutándose y que MySQL esté configurado por sus responsables. La URL `/api` usa el proxy de Vite a `http://localhost:8080`. Esta pantalla no se conecta por sí sola al abrir la app y no envía datos de demostración al servidor.

El cliente comercial de la demo tiene correo, teléfono, origen y clasificación. El `Cliente` de la API actual utiliza nombre, producto, fechaCompra, estado de atención y observaciones. No se confunden ambas entidades ni se traducen estados comerciales a estados de reclamo.

## Pruebas y compilación
```sh
npm test
npm run format:check
npm run build
npm run preview
```
Las pruebas incluyen reglas, solicitudes HTTP y 13 escenarios de interfaz en un DOM simulado. No sustituyen una prueba visual en Chrome ni una prueba contra la base de datos del grupo. El informe detalla los resultados y las limitaciones. `dist` se genera con `npm run build` y contiene los archivos estáticos para el servidor.

## Repositorio y entrega
El enlace del repositorio del grupo está en `ENLACE_REPOSITORIO.txt`. Esta entrega fue versionada localmente; **sus archivos no se han publicado en GitHub**. Antes de entregar en SENA, incorpora `proyecto` como una nueva carpeta `frontend-aa4-ev03` del repositorio, siguiendo `documentacion/INTEGRAR_EN_REPOSITORIO.md` y sube la rama mediante tus credenciales. No reemplaces el proyecto Maven, `src`, `android` ni `api-proyecto`.

`historial-aa4-ev03.bundle` permite recuperar el historial Git independiente del paquete. No debes forzar su historial sobre el repositorio compartido. El bundle y `HISTORIAL_GIT.txt` documentan los commits realmente creados.

## Límites de esta evidencia
No se afirma que el CRM completo esté terminado. Autenticación de producción, autorizaciones de servidor, notificaciones SMS/correo, tareas programadas, integración de proyectos solares, facturación, encuestas y despliegue están fuera de esta implementación. Los perfiles de revisión son una simulación visual y no son un inicio de sesión real. La marca tipográfica es una referencia gráfica, no el logotipo oficial entregado por la empresa.

La matriz de trazabilidad, el inventario de fuentes y las decisiones resuelven las diferencias entre documentos. Los aportes de compañeros se identifican como antecedentes y no se presentan como código creado o probado en esta evidencia.
