/** Reglas puras: se verifican sin navegador ni base de datos. */
export const ESTADOS_CLIENTE = ["Activo", "Prospecto", "En prueba", "Inactivo"];
export const TIPOS_CLIENTE = ["Persona natural", "Empresa"];
export const ESTADOS_CASO = ["Pendiente", "En proceso", "Resuelto"];
export const hoy = () => {
  const fecha = new Date();
  return `${fecha.getFullYear()}-${String(fecha.getMonth() + 1).padStart(2, "0")}-${String(fecha.getDate()).padStart(2, "0")}`;
};
export const nuevoId = (prefijo) => `${prefijo}-${crypto.randomUUID()}`;
export const moneda = (valor) =>
  new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0,
  }).format(valor);
export const fechaTexto = (valor) =>
  valor
    ? new Intl.DateTimeFormat("es-CO", { dateStyle: "medium" }).format(
        new Date(`${valor}T12:00:00`),
      )
    : "Sin fecha";
export const normalizar = (texto) =>
  String(texto ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();

export function fechaValida(valor) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(valor || "")) return false;
  const fecha = new Date(`${valor}T12:00:00Z`);
  return (
    !Number.isNaN(fecha.getTime()) && fecha.toISOString().slice(0, 10) === valor
  );
}

/** RF 1.1: se usan los limites mas restrictivos de los SQL adjuntos. */
export function validarCliente(cliente) {
  const errores = {};
  if (!cliente.nombre?.trim() || cliente.nombre.trim().length > 100)
    errores.nombre = "Escribe un nombre de 1 a 100 caracteres.";
  if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cliente.correo || "") ||
    cliente.correo.length > 150
  )
    errores.correo = "Escribe un correo válido (máximo 150 caracteres).";
  if (!/^\+?[\d\s()-]{7,20}$/.test(cliente.telefono || ""))
    errores.telefono = "Escribe un teléfono de 7 a 20 caracteres.";
  if (!ESTADOS_CLIENTE.includes(cliente.estado))
    errores.estado = "Selecciona un estado válido.";
  if (!TIPOS_CLIENTE.includes(cliente.tipo))
    errores.tipo = "Selecciona un tipo de cliente.";
  if (!["Directo", "Feria empresarial", "Contáctenos"].includes(cliente.origen))
    errores.origen = "Selecciona el origen del contacto.";
  if (!cliente.producto?.trim() || cliente.producto.trim().length > 100)
    errores.producto = "Indica el producto de interés (máximo 100 caracteres).";
  if (
    cliente.fecha_compra &&
    (!fechaValida(cliente.fecha_compra) || cliente.fecha_compra > hoy())
  )
    errores.fecha_compra =
      "La compra debe tener una fecha válida que no sea futura.";
  if (!fechaValida(cliente.proximoContacto))
    errores.proximoContacto = "Indica una fecha válida de próximo contacto.";
  if ((cliente.observaciones || "").length > 245)
    errores.observaciones = "Escribe máximo 245 caracteres.";
  return errores;
}

/** RF 4.2: dos meses calendario, no una aproximacion fija de 60 dias. */
export function esProductoNuevo(fechaCreacion, referencia = hoy()) {
  if (
    !fechaValida(fechaCreacion) ||
    !fechaValida(referencia) ||
    fechaCreacion > referencia
  )
    return false;
  const inicio = new Date(`${fechaCreacion}T12:00:00Z`);
  const mesDestino = inicio.getUTCMonth() + 2;
  const ultimoDia = new Date(
    Date.UTC(inicio.getUTCFullYear(), mesDestino + 1, 0),
  ).getUTCDate();
  const limite = new Date(
    Date.UTC(
      inicio.getUTCFullYear(),
      mesDestino,
      Math.min(inicio.getUTCDate(), ultimoDia),
      12,
    ),
  );
  return new Date(`${referencia}T12:00:00Z`) < limite;
}

/** Los prefijos peligrosos se neutralizan al exportar a hojas de calculo. */
export function crearCsv(filas) {
  return (
    "\ufeff" +
    filas
      .map((fila) =>
        fila
          .map((valor) => {
            let texto = String(valor ?? "");
            if (/^[\s]*[=+@-]/.test(texto)) texto = "'" + texto;
            return '"' + texto.replaceAll('"', '""') + '"';
          })
          .join(";"),
      )
      .join("\r\n")
  );
}

export function validarVenta(venta, clientes) {
  if (
    !clientes.some(
      (c) => c.idcliente === venta.idcliente && c.estado !== "Inactivo",
    )
  )
    return "Selecciona un cliente activo en el sistema.";
  if (!venta.producto?.trim() || venta.producto.trim().length > 100)
    return "Indica un producto de hasta 100 caracteres.";
  if (
    !Number.isInteger(Number(venta.cantidad)) ||
    Number(venta.cantidad) < 1 ||
    Number(venta.cantidad) > 9999
  )
    return "La cantidad debe ser un entero entre 1 y 9999.";
  if (
    !Number.isFinite(Number(venta.precio_unitario)) ||
    Number(venta.precio_unitario) <= 0 ||
    Number(venta.precio_unitario) > 99999999.99
  )
    return "El precio debe ser mayor que cero y compatible con DECIMAL(10,2).";
  if (!fechaValida(venta.fecha_venta) || venta.fecha_venta > hoy())
    return "La fecha de venta debe ser válida y no futura.";
  return "";
}

export function obtenerAlertas(datos) {
  const alertas = datos.clientes
    .filter(
      (c) =>
        c.estado !== "Inactivo" &&
        c.proximoContacto &&
        c.proximoContacto <= hoy(),
    )
    .map((c) => ({
      id: c.idcliente,
      clase: "interna",
      titulo: "Seguimiento pendiente",
      detalle: `${c.nombre} · ${fechaTexto(c.proximoContacto)}`,
      pagina: "seguimiento",
    }));
  return [
    ...alertas,
    ...datos.casos
      .filter((c) => c.estado !== "Resuelto")
      .map((c) => ({
        id: c.id,
        clase: "externa",
        titulo: `${c.tipo} · ${c.radicado}`,
        detalle: c.descripcion,
        pagina: "pqrs",
      })),
  ];
}
