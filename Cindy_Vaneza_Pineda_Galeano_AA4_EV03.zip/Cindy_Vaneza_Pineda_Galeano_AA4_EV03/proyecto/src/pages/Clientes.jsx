import React, { useState, useCallback } from "react";
import {
  Badge,
  Empty,
  Field,
  Icon,
  Modal,
  PageTitle,
} from "../components/UI.jsx";
import {
  ESTADOS_CLIENTE,
  TIPOS_CLIENTE,
  validarCliente,
  normalizar,
  fechaTexto,
  hoy,
  nuevoId,
  moneda,
} from "../domain/model.js";
const nuevoCliente = () => ({
  nombre: "",
  correo: "",
  telefono: "",
  tipo: "Persona natural",
  estado: "Prospecto",
  origen: "Directo",
  producto: "",
  fecha_compra: "",
  observaciones: "",
  proximoContacto: hoy(),
  consentimiento: false,
});

export default function Clientes({
  datos,
  actualizar,
  puedeEditar,
  responsable,
}) {
  const [busqueda, setBusqueda] = useState("");
  const [estado, setEstado] = useState("");
  const [pagina, setPagina] = useState(1);
  const [edicion, setEdicion] = useState(null);
  const [detalle, setDetalle] = useState(null);
  const [confirmar, setConfirmar] = useState(null);
  const [errores, setErrores] = useState({});
  const cerrar = useCallback(() => {
    setEdicion(null);
    setDetalle(null);
    setConfirmar(null);
    setErrores({});
  }, []);
  const filtrados = datos.clientes.filter(
    (c) =>
      (!estado || c.estado === estado) &&
      normalizar(`${c.nombre} ${c.correo} ${c.producto}`).includes(
        normalizar(busqueda),
      ),
  );
  const paginas = Math.max(1, Math.ceil(filtrados.length / 6));
  const actual = Math.min(pagina, paginas);
  const filas = filtrados.slice((actual - 1) * 6, actual * 6);
  const clienteDetalle = datos.clientes.find((c) => c.idcliente === detalle);
  function guardar(evento) {
    evento.preventDefault();
    if (!puedeEditar) return;
    const erroresActuales = validarCliente(edicion);
    setErrores(erroresActuales);
    if (Object.keys(erroresActuales).length) return;
    if (
      datos.clientes.some(
        (c) =>
          c.idcliente !== edicion.idcliente &&
          normalizar(c.correo.trim()) === normalizar(edicion.correo.trim()),
      )
    ) {
      setErrores({ correo: "Ya hay un cliente con este correo." });
      return;
    }
    const cliente = {
      ...edicion,
      nombre: edicion.nombre.trim(),
      correo: edicion.correo.trim(),
      producto: edicion.producto.trim(),
      idcliente: edicion.idcliente || nuevoId("CLI"),
    };
    const clientes = edicion.idcliente
      ? datos.clientes.map((c) =>
          c.idcliente === cliente.idcliente ? cliente : c,
        )
      : [cliente, ...datos.clientes];
    if (
      actualizar(
        { ...datos, clientes },
        `${edicion.idcliente ? "Actualizó" : "Registró"} cliente: ${cliente.nombre}`,
        responsable,
      )
    )
      cerrar();
  }
  function desactivar() {
    if (!puedeEditar) return;
    if (
      actualizar(
        {
          ...datos,
          clientes: datos.clientes.map((c) =>
            c.idcliente === confirmar.idcliente
              ? { ...c, estado: "Inactivo" }
              : c,
          ),
        },
        `Desactivó cliente: ${confirmar.nombre}`,
        responsable,
      )
    )
      cerrar();
  }
  const cambiar = (campo, valor) =>
    setEdicion((c) => ({ ...c, [campo]: valor }));
  return (
    <>
      <PageTitle
        title="Clientes"
        description="Cada relación comienza con conocer a tu cliente."
      >
        {puedeEditar && (
          <button
            className="button primary"
            onClick={() => {
              setErrores({});
              setEdicion(nuevoCliente());
            }}
          >
            <Icon name="plus" />
            Nuevo cliente
          </button>
        )}
      </PageTitle>
      <div className="panel">
        <div className="panel-heading">
          <div>
            <h2>Directorio de clientes</h2>
            <p>{datos.clientes.length} relaciones registradas</p>
          </div>
          <Badge tone="green">Gestión comercial</Badge>
        </div>
        <div className="filters">
          <label className="search">
            <Icon name="search" />
            <input
              aria-label="Buscar clientes"
              placeholder="Buscar por nombre, correo o producto..."
              value={busqueda}
              onChange={(e) => {
                setBusqueda(e.target.value);
                setPagina(1);
              }}
            />
          </label>
          <select
            aria-label="Filtrar estado de cliente"
            value={estado}
            onChange={(e) => {
              setEstado(e.target.value);
              setPagina(1);
            }}
          >
            <option value="">Todos los estados</option>
            {ESTADOS_CLIENTE.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </div>
        {filas.length ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Cliente</th>
                  <th>Producto de interés</th>
                  <th>Estado</th>
                  <th>Próximo contacto</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filas.map((c) => (
                  <tr key={c.idcliente}>
                    <td>
                      <div className="person">
                        <span className="avatar">
                          {c.nombre.slice(0, 2).toUpperCase()}
                        </span>
                        <div>
                          <strong>{c.nombre}</strong>
                          <small>{c.correo}</small>
                        </div>
                      </div>
                    </td>
                    <td>
                      {c.producto}
                      <small>
                        {c.tipo} · {c.origen}
                      </small>
                    </td>
                    <td>
                      <Badge>{c.estado}</Badge>
                    </td>
                    <td>{fechaTexto(c.proximoContacto)}</td>
                    <td>
                      <div className="row-actions">
                        <button
                          className="text-button"
                          onClick={() => setDetalle(c.idcliente)}
                          aria-label={`Ver ficha de ${c.nombre}`}
                        >
                          Ver ficha
                        </button>
                        {puedeEditar && (
                          <>
                            <button
                              className="text-button"
                              onClick={() => {
                                setEdicion({ ...c });
                                setErrores({});
                              }}
                              aria-label={`Editar ${c.nombre}`}
                            >
                              Editar
                            </button>
                            {c.estado !== "Inactivo" && (
                              <button
                                className="text-button danger-text"
                                onClick={() => setConfirmar(c)}
                                aria-label={`Desactivar ${c.nombre}`}
                              >
                                Desactivar
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty />
        )}
        <div className="pagination">
          <span>
            {filtrados.length} resultados · Página {actual} de {paginas}
          </span>
          <div>
            <button
              disabled={actual <= 1}
              onClick={() => setPagina(actual - 1)}
            >
              Anterior
            </button>
            <button
              disabled={actual >= paginas}
              onClick={() => setPagina(actual + 1)}
            >
              Siguiente
            </button>
          </div>
        </div>
      </div>
      {edicion && (
        <Modal
          title={edicion.idcliente ? "Editar cliente" : "Nuevo cliente"}
          onClose={cerrar}
          wide
        >
          <form onSubmit={guardar} noValidate>
            <p className="form-intro">
              Los campos con * son obligatorios. Datos guardados solo en este
              navegador.
            </p>
            <div className="form-grid">
              <Field label="Nombre o razón social *" error={errores.nombre}>
                <input
                  autoFocus
                  maxLength={100}
                  value={edicion.nombre}
                  onChange={(e) => cambiar("nombre", e.target.value)}
                />
              </Field>
              <Field label="Correo electrónico *" error={errores.correo}>
                <input
                  type="email"
                  maxLength={150}
                  value={edicion.correo}
                  onChange={(e) => cambiar("correo", e.target.value)}
                />
              </Field>
              <Field label="Teléfono *" error={errores.telefono}>
                <input
                  type="tel"
                  maxLength={20}
                  value={edicion.telefono}
                  onChange={(e) => cambiar("telefono", e.target.value)}
                />
              </Field>
              <Field label="Tipo de cliente *" error={errores.tipo}>
                <select
                  value={edicion.tipo}
                  onChange={(e) => cambiar("tipo", e.target.value)}
                >
                  {TIPOS_CLIENTE.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </Field>
              <Field label="Estado *" error={errores.estado}>
                <select
                  value={edicion.estado}
                  onChange={(e) => cambiar("estado", e.target.value)}
                >
                  {ESTADOS_CLIENTE.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </Field>
              <Field label="Origen del contacto *" error={errores.origen}>
                <select
                  value={edicion.origen}
                  onChange={(e) => cambiar("origen", e.target.value)}
                >
                  {["Directo", "Feria empresarial", "Contáctenos"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </Field>
              <Field
                label="Producto o servicio de interés *"
                error={errores.producto}
              >
                <input
                  maxLength={100}
                  value={edicion.producto}
                  onChange={(e) => cambiar("producto", e.target.value)}
                />
              </Field>
              <Field
                label="Fecha de compra"
                error={errores.fecha_compra}
                hint="Opcional para prospectos; obligatoria al registrar una venta."
              >
                <input
                  type="date"
                  max={hoy()}
                  value={edicion.fecha_compra}
                  onChange={(e) => cambiar("fecha_compra", e.target.value)}
                />
              </Field>
              <Field label="Próximo contacto *" error={errores.proximoContacto}>
                <input
                  type="date"
                  value={edicion.proximoContacto}
                  onChange={(e) => cambiar("proximoContacto", e.target.value)}
                />
              </Field>
              <Field label="Observaciones" error={errores.observaciones}>
                <textarea
                  maxLength={245}
                  value={edicion.observaciones}
                  onChange={(e) => cambiar("observaciones", e.target.value)}
                />
              </Field>
            </div>
            <label className="checkbox">
              <input
                type="checkbox"
                checked={edicion.consentimiento}
                onChange={(e) => cambiar("consentimiento", e.target.checked)}
              />
              El cliente autoriza recibir comunicaciones comerciales.
            </label>
            <div className="form-actions">
              <button type="button" className="button" onClick={cerrar}>
                Cancelar
              </button>
              <button className="button primary" type="submit">
                Guardar cliente
              </button>
            </div>
          </form>
        </Modal>
      )}
      {clienteDetalle && (
        <Modal title="Ficha del cliente" onClose={cerrar} wide>
          <h3>{clienteDetalle.nombre}</h3>
          <div className="detail-grid">
            <p>
              <small>Correo</small>
              {clienteDetalle.correo}
            </p>
            <p>
              <small>Teléfono</small>
              {clienteDetalle.telefono}
            </p>
            <p>
              <small>Estado</small>
              <Badge>{clienteDetalle.estado}</Badge>
            </p>
            <p>
              <small>Comunicaciones comerciales</small>
              {clienteDetalle.consentimiento ? "Autorizadas" : "No autorizadas"}
            </p>
          </div>
          <p>{clienteDetalle.observaciones || "Sin observaciones."}</p>
          <h3>Historial de compras</h3>
          {datos.ventas
            .filter((v) => v.idcliente === detalle)
            .map((v) => (
              <p key={v.idventa}>
                {fechaTexto(v.fecha_venta)} · {v.producto} ·{" "}
                {moneda(v.cantidad * v.precio_unitario)}
              </p>
            ))}
          {!datos.ventas.some((v) => v.idcliente === detalle) && (
            <p className="muted">Sin compras registradas.</p>
          )}
          <h3>Seguimientos realizados</h3>
          {datos.seguimientos
            .filter((v) => v.idcliente === detalle)
            .map((v) => (
              <div className="timeline-item" key={v.id}>
                <strong>{v.responsable}</strong>
                <small>{fechaTexto(v.fecha)}</small>
                <p>{v.resultado}</p>
                <p className="muted">Expectativa: {v.expectativa}</p>
              </div>
            ))}
          {!datos.seguimientos.some((v) => v.idcliente === detalle) && (
            <p className="muted">Sin seguimientos realizados.</p>
          )}
        </Modal>
      )}
      {confirmar && (
        <Modal title="Desactivar cliente" onClose={cerrar}>
          <p>
            ¿Deseas desactivar a <strong>{confirmar.nombre}</strong>? Su
            historial se conservará. Podrás reactivarlo desde Editar.
          </p>
          <div className="form-actions">
            <button className="button" onClick={cerrar}>
              Cancelar
            </button>
            <button className="button danger" onClick={desactivar}>
              Confirmar desactivación
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}
