import React, { useState, useCallback } from "react";
import {
  PageTitle,
  Icon,
  Modal,
  Field,
  Badge,
  Empty,
} from "../components/UI.jsx";
import { hoy, nuevoId, fechaTexto, crearCsv } from "../domain/model.js";
import { descargar } from "../services/download.js";
export default function Seguimiento({
  datos,
  actualizar,
  puedeEditar,
  responsable,
}) {
  const [cliente, setCliente] = useState(null);
  const [form, setForm] = useState({
    resultado: "",
    expectativa: "",
    proximoContacto: hoy(),
    canal: "Llamada",
  });
  const cerrar = useCallback(() => setCliente(null), []);
  const pendientes = datos.clientes
    .filter((c) => c.estado !== "Inactivo")
    .sort((a, b) => a.proximoContacto.localeCompare(b.proximoContacto));
  function guardar(e) {
    e.preventDefault();
    if (!puedeEditar || !form.resultado.trim() || !form.expectativa.trim())
      return;
    const seguimiento = {
      ...form,
      id: nuevoId("SEG"),
      idcliente: cliente.idcliente,
      fecha: hoy(),
      responsable,
    };
    if (
      actualizar(
        {
          ...datos,
          clientes: datos.clientes.map((c) =>
            c.idcliente === cliente.idcliente
              ? { ...c, proximoContacto: form.proximoContacto }
              : c,
          ),
          seguimientos: [seguimiento, ...datos.seguimientos],
        },
        `Registró seguimiento de ${cliente.nombre}`,
        responsable,
      )
    )
      cerrar();
  }
  const exportar = () =>
    descargar(
      "MEDELED_seguimientos.csv",
      crearCsv([
        [
          "Cliente",
          "Fecha",
          "Canal",
          "Responsable",
          "Resultado",
          "Expectativa",
          "Próximo contacto",
        ],
        ...datos.seguimientos.map((s) => [
          datos.clientes.find((c) => c.idcliente === s.idcliente)?.nombre,
          s.fecha,
          s.canal,
          s.responsable,
          s.resultado,
          s.expectativa,
          s.proximoContacto,
        ]),
      ]),
    );
  return (
    <>
      <PageTitle
        title="Seguimiento posventa"
        description="Una conversación a tiempo fortalece la confianza."
      >
        <button className="button" onClick={exportar}>
          <Icon name="down" />
          Descargar historial
        </button>
      </PageTitle>
      <div className="info-note">
        Las fechas pendientes generan alertas internas mientras consultas la
        aplicación. No se envían correos ni SMS.
      </div>
      <div className="panel">
        <div className="panel-heading">
          <h2>Agenda de contactos</h2>
          <Badge tone="blue">
            {pendientes.filter((c) => c.proximoContacto <= hoy()).length} por
            atender
          </Badge>
        </div>
        {pendientes.length ? (
          pendientes.map((c) => (
            <div className="list-row" key={c.idcliente}>
              <div className="person">
                <span className="avatar">
                  <Icon name="calendar" />
                </span>
                <div>
                  <strong>{c.nombre}</strong>
                  <small>
                    {c.producto} · {c.telefono}
                  </small>
                </div>
              </div>
              <div className="row-actions">
                <Badge tone={c.proximoContacto <= hoy() ? "yellow" : "gray"}>
                  {fechaTexto(c.proximoContacto)}
                </Badge>
                {puedeEditar && (
                  <button
                    className="button"
                    onClick={() => {
                      setCliente(c);
                      setForm({
                        resultado: "",
                        expectativa: "",
                        proximoContacto: hoy(),
                        canal: "Llamada",
                      });
                    }}
                  >
                    Registrar contacto
                  </button>
                )}
              </div>
            </div>
          ))
        ) : (
          <Empty />
        )}
      </div>
      <div className="panel space-top">
        <div className="panel-heading">
          <h2>Interacciones realizadas</h2>
        </div>
        {datos.seguimientos.length ? (
          datos.seguimientos.map((s) => (
            <div className="timeline-item padded" key={s.id}>
              <strong>
                {
                  datos.clientes.find((c) => c.idcliente === s.idcliente)
                    ?.nombre
                }{" "}
                · {s.canal}
              </strong>
              <small>
                {fechaTexto(s.fecha)} · Responsable: {s.responsable}
              </small>
              <p>{s.resultado}</p>
              <p className="muted">Expectativa acordada: {s.expectativa}</p>
            </div>
          ))
        ) : (
          <Empty
            title="Sin interacciones registradas"
            text="Registra el resultado de tu próximo contacto con un cliente."
          />
        )}
      </div>
      {cliente && (
        <Modal title={`Contacto: ${cliente.nombre}`} onClose={cerrar}>
          <form onSubmit={guardar}>
            <Field label="Canal de contacto">
              <select
                value={form.canal}
                onChange={(e) => setForm({ ...form, canal: e.target.value })}
              >
                {["Llamada", "Correo", "Visita", "Feria empresarial"].map(
                  (v) => (
                    <option key={v}>{v}</option>
                  ),
                )}
              </select>
            </Field>
            <Field label="Resultado o solución dada *">
              <textarea
                required
                maxLength={500}
                value={form.resultado}
                onChange={(e) =>
                  setForm({ ...form, resultado: e.target.value })
                }
              />
            </Field>
            <Field label="Expectativa acordada con el cliente *">
              <textarea
                required
                maxLength={500}
                value={form.expectativa}
                onChange={(e) =>
                  setForm({ ...form, expectativa: e.target.value })
                }
              />
            </Field>
            <Field label="Próximo contacto *">
              <input
                required
                type="date"
                min={hoy()}
                value={form.proximoContacto}
                onChange={(e) =>
                  setForm({ ...form, proximoContacto: e.target.value })
                }
              />
            </Field>
            <p className="muted">Responsable registrado: {responsable}</p>
            <div className="form-actions">
              <button type="button" className="button" onClick={cerrar}>
                Cancelar
              </button>
              <button className="button primary">Guardar seguimiento</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
