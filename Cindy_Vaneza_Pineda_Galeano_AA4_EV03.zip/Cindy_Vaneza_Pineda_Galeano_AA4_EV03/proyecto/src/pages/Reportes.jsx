import React from "react";
import { PageTitle, Icon, Empty } from "../components/UI.jsx";
import { crearCsv, moneda, hoy } from "../domain/model.js";
import { descargar } from "../services/download.js";
export default function Reportes({ datos }) {
  const resumen = [
    ["Clientes", datos.clientes.length],
    [
      "Clientes activos",
      datos.clientes.filter((c) => c.estado === "Activo").length,
    ],
    [
      "Clientes prospecto",
      datos.clientes.filter((c) => c.estado === "Prospecto").length,
    ],
    ["Ventas", datos.ventas.length],
    [
      "Valor de ventas COP",
      datos.ventas.reduce((s, v) => s + v.cantidad * v.precio_unitario, 0),
    ],
    [
      "PQRS sin resolver",
      datos.casos.filter((c) => c.estado !== "Resuelto").length,
    ],
    ["Interacciones registradas", datos.seguimientos.length],
  ];
  return (
    <>
      <PageTitle
        title="Reportes"
        description="Información para dar continuidad y tomar decisiones."
      >
        <button className="button" onClick={() => window.print()}>
          Imprimir
        </button>
        <button
          className="button primary"
          onClick={() =>
            descargar(
              `MEDELED_resumen_${hoy()}.csv`,
              crearCsv([["Indicador", "Valor"], ...resumen]),
            )
          }
        >
          <Icon name="down" />
          Descargar resumen
        </button>
      </PageTitle>
      <div className="dashboard-grid">
        <div className="panel">
          <div className="panel-heading">
            <h2>Resumen de gestión</h2>
          </div>
          {resumen.map(([k, v]) => (
            <div className="list-row" key={k}>
              <span>{k}</span>
              <strong>{k === "Valor de ventas COP" ? moneda(v) : v}</strong>
            </div>
          ))}
        </div>
        <div className="panel">
          <div className="panel-heading">
            <h2>Actividad reciente</h2>
          </div>
          {datos.actividad.length ? (
            datos.actividad.slice(0, 12).map((a) => (
              <div className="timeline-item padded" key={a.id}>
                <strong>{a.accion}</strong>
                <small>
                  {a.responsable} · {new Date(a.fecha).toLocaleString("es-CO")}
                </small>
              </div>
            ))
          ) : (
            <Empty
              title="Aún no hay actividad"
              text="Los cambios realizados se mostrarán aquí."
            />
          )}
        </div>
      </div>
      <div className="info-note space-top">
        Estos indicadores se calculan a partir de los registros locales. Los
        reportes CSV de detalle están en Ventas y Seguimiento.
      </div>
    </>
  );
}
