import React, { useState, useCallback } from "react";
import {
  PageTitle,
  Icon,
  Modal,
  Field,
  Badge,
  Empty,
} from "../components/UI.jsx";
import {
  hoy,
  nuevoId,
  moneda,
  fechaTexto,
  validarVenta,
  crearCsv,
} from "../domain/model.js";
import { descargar } from "../services/download.js";
export default function Ventas({
  datos,
  actualizar,
  puedeEditar,
  responsable,
}) {
  const [form, setForm] = useState(null);
  const [error, setError] = useState("");
  const cerrar = useCallback(() => {
    setForm(null);
    setError("");
  }, []);
  const nombre = (id) =>
    datos.clientes.find((c) => c.idcliente === id)?.nombre ||
    "Cliente no disponible";
  function guardar(e) {
    e.preventDefault();
    if (!puedeEditar) return;
    const mensaje = validarVenta(form, datos.clientes);
    setError(mensaje);
    if (mensaje) return;
    const venta = {
      ...form,
      idventa: nuevoId("VEN"),
      cantidad: Number(form.cantidad),
      precio_unitario: Number(Number(form.precio_unitario).toFixed(2)),
      estado: "Confirmada",
    };
    const clientes = datos.clientes.map((c) =>
      c.idcliente === venta.idcliente
        ? {
            ...c,
            estado: "Activo",
            producto: venta.producto,
            fecha_compra: venta.fecha_venta,
          }
        : c,
    );
    if (
      actualizar(
        { ...datos, clientes, ventas: [venta, ...datos.ventas] },
        `Registró venta para ${nombre(venta.idcliente)}`,
        responsable,
      )
    )
      cerrar();
  }
  function exportar() {
    descargar(
      "MEDELED_ventas.csv",
      crearCsv([
        [
          "Fecha",
          "Cliente",
          "Correo actual",
          "Teléfono actual",
          "Producto",
          "Cantidad",
          "Precio unitario",
          "Total",
          "Estado",
        ],
        ...datos.ventas.map((v) => {
          const c = datos.clientes.find((c) => c.idcliente === v.idcliente);
          return [
            v.fecha_venta,
            nombre(v.idcliente),
            c?.correo,
            c?.telefono,
            v.producto,
            v.cantidad,
            v.precio_unitario,
            v.cantidad * v.precio_unitario,
            v.estado,
          ];
        }),
      ]),
    );
  }
  return (
    <>
      <PageTitle
        title="Ventas"
        description="Compras conectadas con cada relación comercial."
      >
        <button className="button" onClick={exportar}>
          <Icon name="down" />
          Exportar reporte
        </button>
        {puedeEditar && (
          <button
            className="button primary"
            onClick={() =>
              setForm({
                idcliente: "",
                producto: "",
                cantidad: 1,
                precio_unitario: "",
                fecha_venta: hoy(),
              })
            }
          >
            <Icon name="plus" />
            Registrar venta
          </button>
        )}
      </PageTitle>
      <div className="stats two">
        <div className="stat">
          <p>Ventas registradas</p>
          <strong>{datos.ventas.length}</strong>
          <small>Historial comercial de demostración</small>
        </div>
        <div className="stat">
          <p>Valor total registrado</p>
          <strong>
            {moneda(
              datos.ventas.reduce(
                (sum, v) => sum + v.cantidad * v.precio_unitario,
                0,
              ),
            )}
          </strong>
          <small>Valores expresados en pesos colombianos</small>
        </div>
      </div>
      <div className="panel">
        <div className="panel-heading">
          <h2>Historial de ventas</h2>
          <Badge tone="green">Clientes y productos</Badge>
        </div>
        {datos.ventas.length ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Cliente</th>
                  <th>Producto</th>
                  <th>Cantidad</th>
                  <th>Total</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {datos.ventas.map((v) => (
                  <tr key={v.idventa}>
                    <td>{fechaTexto(v.fecha_venta)}</td>
                    <td>
                      <strong>{nombre(v.idcliente)}</strong>
                    </td>
                    <td>{v.producto}</td>
                    <td>{v.cantidad}</td>
                    <td>{moneda(v.cantidad * v.precio_unitario)}</td>
                    <td>
                      <Badge>{v.estado}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty title="Aún no hay ventas" />
        )}
      </div>
      {form && (
        <Modal title="Registrar venta" onClose={cerrar}>
          <form onSubmit={guardar}>
            <div className="form-grid">
              <Field label="Cliente *">
                <select
                  required
                  value={form.idcliente}
                  onChange={(e) =>
                    setForm({ ...form, idcliente: e.target.value })
                  }
                >
                  <option value="">Selecciona un cliente</option>
                  {datos.clientes
                    .filter((c) => c.estado !== "Inactivo")
                    .map((c) => (
                      <option key={c.idcliente} value={c.idcliente}>
                        {c.nombre}
                      </option>
                    ))}
                </select>
              </Field>
              <Field label="Producto o servicio *">
                <input
                  required
                  maxLength={100}
                  value={form.producto}
                  onChange={(e) =>
                    setForm({ ...form, producto: e.target.value })
                  }
                />
              </Field>
              <Field label="Cantidad *">
                <input
                  required
                  type="number"
                  min="1"
                  max="9999"
                  step="1"
                  value={form.cantidad}
                  onChange={(e) =>
                    setForm({ ...form, cantidad: e.target.value })
                  }
                />
              </Field>
              <Field label="Precio unitario (COP) *">
                <input
                  required
                  type="number"
                  min="0.01"
                  max="99999999.99"
                  step="0.01"
                  value={form.precio_unitario}
                  onChange={(e) =>
                    setForm({ ...form, precio_unitario: e.target.value })
                  }
                />
              </Field>
              <Field label="Fecha de venta *">
                <input
                  required
                  type="date"
                  max={hoy()}
                  value={form.fecha_venta}
                  onChange={(e) =>
                    setForm({ ...form, fecha_venta: e.target.value })
                  }
                />
              </Field>
            </div>
            <p className="total-preview">
              Total:{" "}
              {moneda(Number(form.cantidad) * Number(form.precio_unitario))}
            </p>
            <p className="muted">
              Esta venta local no descuenta existencias ni genera factura.
            </p>
            {error && (
              <p role="alert" className="error">
                {error}
              </p>
            )}
            <div className="form-actions">
              <button type="button" className="button" onClick={cerrar}>
                Cancelar
              </button>
              <button className="button primary">Guardar venta</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
