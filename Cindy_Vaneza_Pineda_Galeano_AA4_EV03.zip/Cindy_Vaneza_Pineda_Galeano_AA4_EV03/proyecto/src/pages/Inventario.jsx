import React, { useState, useCallback } from "react";
import {
  PageTitle,
  Icon,
  Modal,
  Field,
  Badge,
  Empty,
} from "../components/UI.jsx";
import { hoy, nuevoId, fechaTexto, esProductoNuevo } from "../domain/model.js";
export default function Inventario({
  datos,
  actualizar,
  puedeEditar,
  responsable,
}) {
  const [form, setForm] = useState(null);
  const [error, setError] = useState("");
  const cerrar = useCallback(() => setForm(null), []);
  function guardar(e) {
    e.preventDefault();
    if (!puedeEditar) return;
    if (!form.nombre.trim()) {
      setError("Escribe el nombre del producto.");
      return;
    }
    const producto = {
      ...form,
      id: form.id || nuevoId("PRO"),
      nombre: form.nombre.trim(),
      cantidad: Number(form.cantidad),
    };
    const productos = form.id
      ? datos.productos.map((p) => (p.id === form.id ? producto : p))
      : [producto, ...datos.productos];
    if (
      actualizar(
        { ...datos, productos },
        `Actualizó producto: ${producto.nombre}`,
        responsable,
      )
    )
      cerrar();
  }
  return (
    <>
      <PageTitle
        title="Inventario"
        description="Disponibilidad de productos y servicios de MEDELED."
      >
        {puedeEditar && (
          <button
            className="button primary"
            onClick={() => {
              setForm({ nombre: "", cantidad: 0, fechaCreacion: hoy() });
              setError("");
            }}
          >
            <Icon name="plus" />
            Nuevo producto
          </button>
        )}
      </PageTitle>
      <div className="info-note purple-note">
        Los productos nuevos se identifican con una etiqueta morada durante dos
        meses calendario desde su creación.
      </div>
      <div className="panel">
        <div className="panel-heading">
          <h2>Catálogo de productos</h2>
          <Badge tone="purple">
            {
              datos.productos.filter((p) => esProductoNuevo(p.fechaCreacion))
                .length
            }{" "}
            nuevos
          </Badge>
        </div>
        {datos.productos.length ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Producto</th>
                  <th>Cantidad</th>
                  <th>Fecha de creación</th>
                  <th>Novedad</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {datos.productos.map((p) => (
                  <tr
                    key={p.id}
                    className={
                      esProductoNuevo(p.fechaCreacion) ? "new-product" : ""
                    }
                  >
                    <td>
                      <strong>{p.nombre}</strong>
                    </td>
                    <td>{p.cantidad}</td>
                    <td>{fechaTexto(p.fechaCreacion)}</td>
                    <td>
                      {esProductoNuevo(p.fechaCreacion) ? (
                        <Badge tone="purple">Nuevo · 2 meses</Badge>
                      ) : (
                        <Badge>En catálogo</Badge>
                      )}
                    </td>
                    <td>
                      {puedeEditar && (
                        <button
                          className="text-button"
                          onClick={() => {
                            setForm({ ...p });
                            setError("");
                          }}
                        >
                          Editar existencias
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty />
        )}
      </div>
      {form && (
        <Modal
          title={form.id ? "Editar producto" : "Nuevo producto"}
          onClose={cerrar}
        >
          <form onSubmit={guardar}>
            <Field label="Nombre del producto *">
              <input
                required
                maxLength={100}
                value={form.nombre}
                onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              />
            </Field>
            <Field label="Cantidad *">
              <input
                type="number"
                min="0"
                max="1000000"
                step="1"
                required
                value={form.cantidad}
                onChange={(e) => setForm({ ...form, cantidad: e.target.value })}
              />
            </Field>
            <Field label="Fecha de creación *">
              <input
                type="date"
                required
                max={hoy()}
                readOnly={!!form.id}
                value={form.fechaCreacion}
                onChange={(e) =>
                  setForm({ ...form, fechaCreacion: e.target.value })
                }
              />
            </Field>
            {error && (
              <p className="error" role="alert">
                {error}
              </p>
            )}
            <div className="form-actions">
              <button type="button" className="button" onClick={cerrar}>
                Cancelar
              </button>
              <button className="button primary">Guardar producto</button>
            </div>
          </form>
        </Modal>
      )}
    </>
  );
}
