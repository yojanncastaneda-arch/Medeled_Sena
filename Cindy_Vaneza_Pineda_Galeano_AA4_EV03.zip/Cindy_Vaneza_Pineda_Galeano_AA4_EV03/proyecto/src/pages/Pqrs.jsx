import React, { useState, useCallback } from "react";
import {
  PageTitle,
  Icon,
  Modal,
  Field,
  Badge,
  Empty,
} from "../components/UI.jsx";
import { hoy, nuevoId, fechaTexto, ESTADOS_CASO } from "../domain/model.js";
export default function Pqrs({ datos, actualizar, puedeEditar, responsable }) {
  const [form, setForm] = useState(null);
  const [filtro, setFiltro] = useState("");
  const [detalle, setDetalle] = useState(null);
  const [cambio, setCambio] = useState({ estado: "", detalle: "" });
  const cerrar = useCallback(() => {
    setForm(null);
    setDetalle(null);
  }, []);
  const casos = datos.casos.filter((c) => !filtro || c.estado === filtro);
  const nombre = (id) =>
    datos.clientes.find((c) => c.idcliente === id)?.nombre ||
    "Cliente no disponible";
  function guardar(e) {
    e.preventDefault();
    if (!puedeEditar || !form.descripcion.trim()) return;
    const id = nuevoId("PQR");
    const caso = {
      ...form,
      id,
      radicado: `PQR-${hoy().replaceAll("-", "")}-${id.slice(-8).toUpperCase()}`,
      estado: "Pendiente",
      fecha: hoy(),
      historial: [
        {
          fecha: new Date().toISOString(),
          responsable,
          detalle: "Caso recibido.",
        },
      ],
    };
    if (
      actualizar(
        { ...datos, casos: [caso, ...datos.casos] },
        `Registró ${caso.radicado}`,
        responsable,
      )
    )
      cerrar();
  }
  function cambiar(e) {
    e.preventDefault();
    if (!puedeEditar || !cambio.detalle.trim()) return;
    const casos = datos.casos.map((c) =>
      c.id === detalle
        ? {
            ...c,
            estado: cambio.estado,
            historial: [
              ...c.historial,
              { ...cambio, fecha: new Date().toISOString(), responsable },
            ],
          }
        : c,
    );
    if (
      actualizar({ ...datos, casos }, "Actualizó estado de PQRS", responsable)
    )
      cerrar();
  }
  const casoDetalle = datos.casos.find((c) => c.id === detalle);
  return (
    <>
      <PageTitle
        title="PQRS y soporte"
        description="Escuchar, atender y dar continuidad a cada solicitud."
      >
        {puedeEditar && (
          <button
            className="button primary"
            onClick={() =>
              setForm({ idcliente: "", tipo: "Solicitud", descripcion: "" })
            }
          >
            <Icon name="plus" />
            Crear PQRS
          </button>
        )}
      </PageTitle>
      <div className="panel">
        <div className="panel-heading">
          <h2>Bandeja de atención</h2>
          <select
            aria-label="Filtrar estado de PQRS"
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          >
            <option value="">Todos los estados</option>
            {ESTADOS_CASO.map((v) => (
              <option key={v}>{v}</option>
            ))}
          </select>
        </div>
        {casos.length ? (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Radicado</th>
                  <th>Cliente</th>
                  <th>Tipo y descripción</th>
                  <th>Estado</th>
                  <th>Acción</th>
                </tr>
              </thead>
              <tbody>
                {casos.map((c) => (
                  <tr key={c.id}>
                    <td>
                      <strong>{c.radicado}</strong>
                      <small>{fechaTexto(c.fecha)}</small>
                    </td>
                    <td>{nombre(c.idcliente)}</td>
                    <td>
                      <strong>{c.tipo}</strong>
                      <small>{c.descripcion}</small>
                    </td>
                    <td>
                      <Badge>{c.estado}</Badge>
                    </td>
                    <td>
                      <button
                        className="text-button"
                        onClick={() => {
                          setDetalle(c.id);
                          setCambio({ estado: c.estado, detalle: "" });
                        }}
                      >
                        Ver caso
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty />
        )}
      </div>
      {form && (
        <Modal title="Crear PQRS" onClose={cerrar}>
          <form onSubmit={guardar}>
            <Field label="Cliente *">
              <select
                required
                value={form.idcliente}
                onChange={(e) =>
                  setForm({ ...form, idcliente: e.target.value })
                }
              >
                <option value="">Selecciona un cliente</option>
                {datos.clientes
                  .filter((c) => c.estado !== "Inactivo")
                  .map((c) => (
                    <option key={c.idcliente} value={c.idcliente}>
                      {c.nombre}
                    </option>
                  ))}
              </select>
            </Field>
            <Field label="Tipo">
              <select
                value={form.tipo}
                onChange={(e) => setForm({ ...form, tipo: e.target.value })}
              >
                {[
                  "Petición",
                  "Queja",
                  "Reclamo",
                  "Solicitud",
                  "Mantenimiento",
                ].map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </Field>
            <Field label="Descripción *">
              <textarea
                required
                maxLength={500}
                value={form.descripcion}
                onChange={(e) =>
                  setForm({ ...form, descripcion: e.target.value })
                }
              />
            </Field>
            <div className="form-actions">
              <button type="button" className="button" onClick={cerrar}>
                Cancelar
              </button>
              <button className="button primary">Guardar PQRS</button>
            </div>
          </form>
        </Modal>
      )}
      {casoDetalle && (
        <Modal title={casoDetalle.radicado} onClose={cerrar}>
          <h3>{nombre(casoDetalle.idcliente)}</h3>
          <p>{casoDetalle.descripcion}</p>
          <Badge>{casoDetalle.estado}</Badge>
          <h3>Historial del caso</h3>
          {casoDetalle.historial.map((item, i) => (
            <div key={i} className="timeline-item">
              <strong>{item.responsable}</strong>
              <small>{new Date(item.fecha).toLocaleString("es-CO")}</small>
              <p>{item.detalle}</p>
            </div>
          ))}
          {puedeEditar && (
            <form onSubmit={cambiar}>
              <Field label="Nuevo estado">
                <select
                  value={cambio.estado}
                  onChange={(e) =>
                    setCambio({ ...cambio, estado: e.target.value })
                  }
                >
                  {ESTADOS_CASO.map((t) => (
                    <option key={t}>{t}</option>
                  ))}
                </select>
              </Field>
              <Field label="Gestión realizada *">
                <textarea
                  required
                  maxLength={500}
                  value={cambio.detalle}
                  onChange={(e) =>
                    setCambio({ ...cambio, detalle: e.target.value })
                  }
                />
              </Field>
              <div className="form-actions">
                <button className="button primary">Actualizar caso</button>
              </div>
            </form>
          )}
        </Modal>
      )}
    </>
  );
}
