import React, { useState, useCallback } from "react";
import { crearApi } from "../services/api.js";
import { PageTitle, Field, Badge, Modal, Empty } from "../components/UI.jsx";
import { hoy, moneda } from "../domain/model.js";
/** Separa completamente registros remotos de datos de demostracion. */
export default function Api() {
  const [base, setBase] = useState(import.meta.env.VITE_API_BASE_URL || "/api");
  const [conexion, setConexion] = useState("");
  const [datos, setDatos] = useState({ clientes: [], ventas: [] });
  const [ocupado, setOcupado] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [fallo, setFallo] = useState(false);
  const [form, setForm] = useState(null);
  const [eliminar, setEliminar] = useState(null);
  const cerrar = useCallback(() => {
    setForm(null);
    setEliminar(null);
  }, []);
  async function cargar(api) {
    const [clientes, ventas] = await Promise.all([
      api.listarClientes(),
      api.listarVentas(),
    ]);
    if (!Array.isArray(clientes) || !Array.isArray(ventas))
      throw new Error(
        "La respuesta debe contener listas de clientes y ventas.",
      );
    if (
      clientes.some((c) => !Number.isInteger(c.idCliente)) ||
      ventas.some((v) => !Number.isInteger(v.idVenta))
    )
      throw new Error(
        "El contrato recibido difiere de los modelos idCliente/idVenta del repositorio.",
      );
    setDatos({ clientes, ventas });
  }
  async function conectar(e) {
    e.preventDefault();
    setOcupado(true);
    setFallo(false);
    setMensaje("Consultando el servidor...");
    setConexion("");
    setDatos({ clientes: [], ventas: [] });
    try {
      await cargar(crearApi(base));
      setConexion(base.trim());
      setMensaje("Conexión completada: registros obtenidos del servidor.");
    } catch (e) {
      setFallo(true);
      setMensaje(
        e.message || "No se pudo conectar. Revisa el backend, el proxy o CORS.",
      );
    } finally {
      setOcupado(false);
    }
  }
  async function guardar(e) {
    e.preventDefault();
    if (ocupado || !conexion) return;
    setOcupado(true);
    setFallo(false);
    try {
      const api = crearApi(conexion);
      const { tipo, id, ...campos } = form;
      if (
        !campos.producto.trim() ||
        (tipo === "clientes" && !campos.nombre.trim())
      )
        throw new Error(
          "Los campos obligatorios no pueden contener solo espacios.",
        );
      const cuerpo =
        tipo === "clientes"
          ? {
              ...campos,
              nombre: campos.nombre.trim(),
              producto: campos.producto.trim(),
            }
          : {
              ...campos,
              idCliente: Number(campos.idCliente),
              cantidad: Number(campos.cantidad),
              precioUnitario: Number(campos.precioUnitario),
              producto: campos.producto.trim(),
            };
      const guardar =
        tipo === "clientes" ? api.guardarCliente : api.guardarVenta;
      await guardar(cuerpo, id);
      cerrar();
      setMensaje("El servidor confirmó la operación.");
      try {
        await cargar(api);
      } catch (e) {
        setFallo(true);
        setMensaje(
          `Operación guardada; no se pudo refrescar la lista: ${e.message}. Pulsa Consultar servidor antes de repetir.`,
        );
        setConexion("");
      }
    } catch (e) {
      setFallo(true);
      setMensaje(e.message);
    } finally {
      setOcupado(false);
    }
  }
  async function borrar() {
    if (ocupado || !conexion) return;
    setOcupado(true);
    setFallo(false);
    try {
      const api = crearApi(conexion);
      await api.eliminar(eliminar.tipo, eliminar.id);
      cerrar();
      setMensaje("El servidor confirmó la eliminación.");
      try {
        await cargar(api);
      } catch (e) {
        setFallo(true);
        setMensaje(
          `Eliminado; falló la actualización de la lista: ${e.message}`,
        );
        setConexion("");
      }
    } catch (e) {
      setFallo(true);
      setMensaje(e.message);
    } finally {
      setOcupado(false);
    }
  }
  function editarCliente(c) {
    setForm({
      tipo: "clientes",
      id: c?.idCliente,
      nombre: c?.nombre || "",
      producto: c?.producto || "",
      fechaCompra: c?.fechaCompra || hoy(),
      estado: c?.estado || "pendiente",
      observaciones: c?.observaciones || "",
    });
  }
  function editarVenta(v) {
    setForm({
      tipo: "ventas",
      id: v?.idVenta,
      idCliente: v?.idCliente || "",
      producto: v?.producto || "",
      cantidad: v?.cantidad || 1,
      precioUnitario: v?.precioUnitario || "",
      fechaVenta: v?.fechaVenta || hoy(),
      estado: v?.estado || "pendiente",
    });
  }
  const asignar = (campo, valor) => setForm((f) => ({ ...f, [campo]: valor }));
  return (
    <>
      <PageTitle
        title="Conexión con la API del grupo"
        description="Clientes/reclamos y ventas según el código Spring Boot del repositorio."
      />
      <div className="info-note">
        Este módulo consulta y modifica el servidor configurado. No mezcla sus
        registros con la demostración. Los perfiles de revisión locales no
        autorizan operaciones de API; los permisos deben aplicarse en el
        servidor.
      </div>
      <form className="panel api-connection" onSubmit={conectar}>
        <Field
          label="URL base de la API"
          hint="En desarrollo, /api usa el proxy hacia http://localhost:8080."
        >
          <input
            required
            value={base}
            onChange={(e) => {
              setBase(e.target.value);
              setConexion("");
              setDatos({ clientes: [], ventas: [] });
            }}
            placeholder="/api"
            disabled={ocupado}
          />
        </Field>
        <button className="button primary" disabled={ocupado}>
          {ocupado ? "Consultando..." : "Consultar servidor"}
        </button>
      </form>
      {mensaje && (
        <div
          className={`info-note space-top ${fallo ? "error" : ""}`}
          role={fallo ? "alert" : "status"}
        >
          {mensaje}
        </div>
      )}
      {conexion && (
        <>
          <div className="panel space-top">
            <div className="panel-heading">
              <div>
                <h2>Clientes y reclamos posventa</h2>
                <p>Estados del servicio: pendiente, en_proceso y resuelto.</p>
              </div>
              <button
                className="button primary"
                disabled={ocupado}
                onClick={() => editarCliente()}
              >
                Crear cliente API
              </button>
            </div>
            {datos.clientes.length ? (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>ID y nombre</th>
                      <th>Producto</th>
                      <th>Fecha compra</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {datos.clientes.map((c) => (
                      <tr key={c.idCliente}>
                        <td>
                          <strong>
                            #{c.idCliente} · {c.nombre}
                          </strong>
                          <small>{c.observaciones}</small>
                        </td>
                        <td>{c.producto}</td>
                        <td>{c.fechaCompra}</td>
                        <td>
                          <Badge tone="blue">{c.estado}</Badge>
                        </td>
                        <td>
                          <div className="row-actions">
                            <button
                              className="text-button"
                              disabled={ocupado}
                              onClick={() => editarCliente(c)}
                            >
                              Editar API
                            </button>
                            <button
                              className="text-button danger-text"
                              disabled={ocupado}
                              onClick={() =>
                                setEliminar({
                                  tipo: "clientes",
                                  id: c.idCliente,
                                })
                              }
                            >
                              Eliminar API
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <Empty />
            )}
          </div>
          <div className="panel space-top">
            <div className="panel-heading">
              <h2>Ventas del servidor</h2>
              <button
                className="button primary"
                disabled={ocupado || !datos.clientes.length}
                onClick={() => editarVenta()}
              >
                Crear venta API
              </button>
            </div>
            {datos.ventas.length ? (
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Cliente ID</th>
                      <th>Producto</th>
                      <th>Total</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {datos.ventas.map((v) => (
                      <tr key={v.idVenta}>
                        <td>#{v.idVenta}</td>
                        <td>{v.idCliente}</td>
                        <td>{v.producto}</td>
                        <td>
                          {moneda(v.total ?? v.cantidad * v.precioUnitario)}
                        </td>
                        <td>{v.estado}</td>
                        <td>
                          <div className="row-actions">
                            <button
                              className="text-button"
                              disabled={ocupado}
                              onClick={() => editarVenta(v)}
                            >
                              Editar API
                            </button>
                            <button
                              className="text-button danger-text"
                              disabled={ocupado}
                              onClick={() =>
                                setEliminar({ tipo: "ventas", id: v.idVenta })
                              }
                            >
                              Eliminar API
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <Empty />
            )}
          </div>
        </>
      )}
      {form && (
        <Modal
          title={`${form.id ? "Editar" : "Crear"} ${form.tipo === "clientes" ? "cliente" : "venta"} en la API`}
          onClose={cerrar}
        >
          <form onSubmit={guardar}>
            {form.tipo === "clientes" ? (
              <>
                <Field label="Nombre *">
                  <input
                    required
                    maxLength={100}
                    value={form.nombre}
                    onChange={(e) => asignar("nombre", e.target.value)}
                  />
                </Field>
                <Field label="Producto del reclamo *">
                  <input
                    required
                    maxLength={100}
                    value={form.producto}
                    onChange={(e) => asignar("producto", e.target.value)}
                  />
                </Field>
                <Field label="Fecha de compra *">
                  <input
                    required
                    type="date"
                    max={hoy()}
                    value={form.fechaCompra}
                    onChange={(e) => asignar("fechaCompra", e.target.value)}
                  />
                </Field>
                <Field label="Estado de atención">
                  <select
                    value={form.estado}
                    onChange={(e) => asignar("estado", e.target.value)}
                  >
                    {["pendiente", "en_proceso", "resuelto"].map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </Field>
                <Field label="Observaciones (máximo 245 para compatibilidad SQL)">
                  <textarea
                    maxLength={245}
                    value={form.observaciones}
                    onChange={(e) => asignar("observaciones", e.target.value)}
                  />
                </Field>
              </>
            ) : (
              <>
                <Field label="Cliente del servidor *">
                  <select
                    required
                    value={form.idCliente}
                    onChange={(e) => asignar("idCliente", e.target.value)}
                  >
                    <option value="">Selecciona un cliente</option>
                    {datos.clientes.map((c) => (
                      <option key={c.idCliente} value={c.idCliente}>
                        {c.nombre} (#{c.idCliente})
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Producto *">
                  <input
                    required
                    maxLength={100}
                    value={form.producto}
                    onChange={(e) => asignar("producto", e.target.value)}
                  />
                </Field>
                <div className="form-grid">
                  <Field label="Cantidad *">
                    <input
                      required
                      type="number"
                      min="1"
                      max="10000"
                      step="1"
                      value={form.cantidad}
                      onChange={(e) => asignar("cantidad", e.target.value)}
                    />
                  </Field>
                  <Field label="Precio unitario COP *">
                    <input
                      required
                      type="number"
                      min="0.01"
                      max="99999999.99"
                      step="0.01"
                      value={form.precioUnitario}
                      onChange={(e) =>
                        asignar("precioUnitario", e.target.value)
                      }
                    />
                  </Field>
                </div>
                <Field label="Fecha de venta *">
                  <input
                    required
                    type="date"
                    max={hoy()}
                    value={form.fechaVenta}
                    onChange={(e) => asignar("fechaVenta", e.target.value)}
                  />
                </Field>
                <Field label="Estado de venta">
                  <select
                    value={form.estado}
                    onChange={(e) => asignar("estado", e.target.value)}
                  >
                    {["pendiente", "pagada", "anulada"].map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </Field>
              </>
            )}
            {fallo && (
              <p className="error" role="alert">
                {mensaje}
              </p>
            )}
            <div className="form-actions">
              <button
                type="button"
                className="button"
                disabled={ocupado}
                onClick={cerrar}
              >
                Cancelar
              </button>
              <button className="button primary" disabled={ocupado}>
                {ocupado ? "Guardando..." : "Guardar en servidor"}
              </button>
            </div>
          </form>
        </Modal>
      )}
      {eliminar && (
        <Modal title="Confirmar eliminación en servidor" onClose={cerrar}>
          <p>
            Se solicitará eliminar {eliminar.tipo} #{eliminar.id}. El servidor
            debe rechazar con 409 un cliente que tenga ventas.
          </p>
          {fallo && (
            <p className="error" role="alert">
              {mensaje}
            </p>
          )}
          <div className="form-actions">
            <button className="button" disabled={ocupado} onClick={cerrar}>
              Cancelar
            </button>
            <button
              className="button danger"
              disabled={ocupado}
              onClick={borrar}
            >
              Eliminar en servidor
            </button>
          </div>
        </Modal>
      )}
    </>
  );
}
