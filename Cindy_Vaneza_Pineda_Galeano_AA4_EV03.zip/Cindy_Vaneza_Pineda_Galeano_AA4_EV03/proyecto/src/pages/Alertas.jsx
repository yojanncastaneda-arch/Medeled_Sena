import React from "react";
import { PageTitle, Empty } from "../components/UI.jsx";
import { obtenerAlertas } from "../domain/model.js";
export default function Alertas({ datos, navegar }) {
  const alertas = obtenerAlertas(datos);
  return (
    <>
      <PageTitle
        title="Alertas y notificaciones"
        description="Prioriza los contactos y solicitudes que requieren atención."
      />
      <div className="info-note">
        Azul: alertas internas de seguimiento. Rojo: solicitudes externas de
        clientes. Son avisos dentro de esta demostración local.
      </div>
      <div className="alert-grid">
        {alertas.map((a) => (
          <button
            key={a.id}
            className={`alert-card ${a.clase}`}
            onClick={() => navegar(a.pagina)}
          >
            <small>{a.clase === "interna" ? "INTERNA" : "EXTERNA"}</small>
            <h3>{a.titulo}</h3>
            <p>{a.detalle}</p>
            <strong>Atender en el módulo →</strong>
          </button>
        ))}
      </div>
      {!alertas.length && (
        <div className="panel">
          <Empty
            title="No hay pendientes"
            text="Los recordatorios aparecerán según las fechas registradas."
          />
        </div>
      )}
    </>
  );
}
