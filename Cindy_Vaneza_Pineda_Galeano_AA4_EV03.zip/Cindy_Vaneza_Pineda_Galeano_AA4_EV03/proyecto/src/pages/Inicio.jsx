import React from "react";
import { PageTitle, Icon, Badge, Empty } from "../components/UI.jsx";
import { moneda, fechaTexto, hoy, obtenerAlertas } from "../domain/model.js";
export default function Inicio({ datos, navegar }) {
  const activos = datos.clientes.filter((c) => c.estado === "Activo").length;
  const alertas = obtenerAlertas(datos);
  const total = datos.ventas.reduce(
    (s, v) => s + v.cantidad * v.precio_unitario,
    0,
  );
  return (
    <>
      <PageTitle
        title="Cultivamos relaciones duraderas."
        description="Tu panorama comercial y de atención, en un solo lugar."
      >
        <button className="button primary" onClick={() => navegar("clientes")}>
          Gestionar clientes
          <Icon name="arrow" />
        </button>
      </PageTitle>
      <div className="hero">
        <div>
          <Badge tone="light">ENERGÍA QUE CONECTA</Badge>
          <h2>
            Más cerca de tus clientes.
            <br />
            Más lejos con MEDELED.
          </h2>
          <p>
            Convierte cada contacto en una oportunidad de acompañar,
            <br className="desktop-break" /> resolver y construir confianza.
          </p>
          <button className="hero-link" onClick={() => navegar("seguimiento")}>
            Revisar agenda de seguimiento <Icon name="arrow" size={17} />
          </button>
        </div>
        <div className="solar-art" aria-hidden="true">
          <div className="sun"></div>
          <div className="solar-panel">
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
          </div>
          <div className="solar-base"></div>
          <span>MEDELED · ENERGÍA SOSTENIBLE</span>
        </div>
      </div>
      <div className="stats">
        <Stat
          label="Clientes registrados"
          value={datos.clientes.length}
          icon="users"
          note={`${activos} relaciones activas`}
        />
        <Stat
          label="Ventas registradas"
          value={moneda(total)}
          icon="bag"
          note={`${datos.ventas.length} compras en el historial`}
        />
        <Stat
          label="Contactos pendientes"
          value={
            datos.clientes.filter(
              (c) => c.estado !== "Inactivo" && c.proximoContacto <= hoy(),
            ).length
          }
          icon="calendar"
          note="Programados para hoy o antes"
        />
        <Stat
          label="Casos por resolver"
          value={datos.casos.filter((c) => c.estado !== "Resuelto").length}
          icon="message"
          note="PQRS y solicitudes de soporte"
        />
      </div>
      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Próximos contactos</h2>
              <p>Una atención oportuna hace la diferencia.</p>
            </div>
            <button
              className="text-button"
              onClick={() => navegar("seguimiento")}
            >
              Ver agenda →
            </button>
          </div>
          {datos.clientes
            .filter((c) => c.estado !== "Inactivo")
            .sort((a, b) => a.proximoContacto.localeCompare(b.proximoContacto))
            .slice(0, 4)
            .map((c) => (
              <div className="list-row" key={c.idcliente}>
                <div className="person">
                  <span className="avatar">
                    {c.nombre.slice(0, 2).toUpperCase()}
                  </span>
                  <div>
                    <strong>{c.nombre}</strong>
                    <small>{c.producto}</small>
                  </div>
                </div>
                <Badge tone={c.proximoContacto <= hoy() ? "yellow" : "gray"}>
                  {fechaTexto(c.proximoContacto)}
                </Badge>
              </div>
            ))}
        </section>
        <section className="panel">
          <div className="panel-heading">
            <div>
              <h2>Centro de atención</h2>
              <p>Lo que necesita tu atención.</p>
            </div>
            <Icon name="bell" />
          </div>
          {alertas.length ? (
            alertas.slice(0, 3).map((a) => (
              <button
                className={`alert-card ${a.clase}`}
                key={a.id}
                onClick={() => navegar(a.pagina)}
              >
                <strong>{a.titulo}</strong>
                <span>{a.detalle}</span>
                <small>
                  {a.clase === "interna"
                    ? "Alerta interna"
                    : "Solicitud externa"}
                </small>
              </button>
            ))
          ) : (
            <Empty title="Todo al día" text="No hay alertas pendientes." />
          )}
        </section>
      </div>
      <section className="bottom-banner">
        <span className="banner-icon">
          <Icon name="leaf" size={26} />
        </span>
        <div>
          <strong>La fidelización también es acompañar.</strong>
          <p>Registra soluciones y expectativas después de cada interacción.</p>
        </div>
        <button className="text-button" onClick={() => navegar("seguimiento")}>
          Registrar seguimiento →
        </button>
      </section>
    </>
  );
}
function Stat({ label, value, icon, note }) {
  return (
    <div className="stat">
      <div className="stat-top">
        <p>{label}</p>
        <span className="stat-icon">
          <Icon name={icon} />
        </span>
      </div>
      <strong>{value}</strong>
      <small>{note}</small>
    </div>
  );
}
