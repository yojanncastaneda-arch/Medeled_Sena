import { hoy, nuevoId } from "../domain/model.js";
const CLAVE = "medeled-aa4-ev03-v1";
const fechaMas = (dias) => {
  const f = new Date();
  f.setDate(f.getDate() + dias);
  return `${f.getFullYear()}-${String(f.getMonth() + 1).padStart(2, "0")}-${String(f.getDate()).padStart(2, "0")}`;
};

/** Datos ficticios; nunca se importan automaticamente los registros personales del dump. */
export function datosIniciales() {
  const clientes = [
    {
      idcliente: "CLI-DEMO-1",
      nombre: "Empresa Solar Demo",
      correo: "compras@example.com",
      telefono: "3000000001",
      tipo: "Empresa",
      estado: "Activo",
      origen: "Directo",
      producto: "Panel solar 550 W",
      fecha_compra: fechaMas(-20),
      observaciones: "Revisar experiencia de instalación.",
      proximoContacto: hoy(),
      consentimiento: true,
    },
    {
      idcliente: "CLI-DEMO-2",
      nombre: "Cliente de Feria Demo",
      correo: "feria@example.com",
      telefono: "3000000002",
      tipo: "Persona natural",
      estado: "Prospecto",
      origen: "Feria empresarial",
      producto: "Luminaria LED",
      fecha_compra: "",
      observaciones: "Solicita información para su vivienda.",
      proximoContacto: fechaMas(3),
      consentimiento: false,
    },
    {
      idcliente: "CLI-DEMO-3",
      nombre: "Corporación Demo",
      correo: "proyectos@example.com",
      telefono: "3000000003",
      tipo: "Empresa",
      estado: "En prueba",
      origen: "Contáctenos",
      producto: "Kit de iluminación solar",
      fecha_compra: "",
      observaciones: "Seguimiento a prueba del producto.",
      proximoContacto: fechaMas(-1),
      consentimiento: true,
    },
  ];
  return {
    version: 1,
    clientes,
    ventas: [
      {
        idventa: "VEN-DEMO-1",
        idcliente: clientes[0].idcliente,
        producto: "Panel solar 550 W",
        cantidad: 2,
        precio_unitario: 680000,
        fecha_venta: fechaMas(-20),
        estado: "Confirmada",
      },
    ],
    seguimientos: [],
    casos: [
      {
        id: "PQR-DEMO-1",
        radicado: "PQR-DEMO-001",
        idcliente: clientes[0].idcliente,
        tipo: "Solicitud",
        descripcion: "Solicita revisión del rendimiento del panel.",
        estado: "Pendiente",
        fecha: hoy(),
        historial: [
          {
            fecha: new Date().toISOString(),
            responsable: "Datos de demostración",
            detalle: "Caso recibido.",
          },
        ],
      },
    ],
    productos: [
      {
        id: "PRO-DEMO-1",
        nombre: "Panel solar 550 W",
        cantidad: 16,
        fechaCreacion: fechaMas(-10),
      },
      {
        id: "PRO-DEMO-2",
        nombre: "Luminaria LED 40 W",
        cantidad: 32,
        fechaCreacion: fechaMas(-90),
      },
    ],
    actividad: [],
  };
}

export function cargarDatos() {
  const guardado = localStorage.getItem(CLAVE);
  if (!guardado) return datosIniciales();
  try {
    const datos = JSON.parse(guardado);
    if (
      datos.version !== 1 ||
      ![
        "clientes",
        "ventas",
        "seguimientos",
        "casos",
        "productos",
        "actividad",
      ].every((k) => Array.isArray(datos[k]))
    )
      throw new Error();
    return datos;
  } catch {
    // No sobrescribir silenciosamente el contenido si esta corrupto.
    throw new Error(
      "Los datos locales no se pueden leer. Usa otro perfil del navegador o revisa el almacenamiento antes de continuar.",
    );
  }
}

export function guardarDatos(datos) {
  // El llamador confirma cambios de pantalla solo si la escritura es exitosa.
  localStorage.setItem(CLAVE, JSON.stringify(datos));
}

export function conActividad(datos, accion, responsable) {
  return {
    ...datos,
    actividad: [
      {
        id: nuevoId("ACT"),
        accion,
        responsable,
        fecha: new Date().toISOString(),
      },
      ...datos.actividad,
    ].slice(0, 100),
  };
}
