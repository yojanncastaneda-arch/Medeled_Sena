/** Contrato verificado en SolicitudCliente/SolicitudVenta y los controladores del grupo. */
export class ErrorApi extends Error {
  constructor(mensaje, estado) {
    super(mensaje);
    this.estado = estado;
  }
}
export function crearApi(base, transporte = fetch) {
  const raiz = base.trim().replace(/\/+$/, "");
  if (
    !(raiz.startsWith("/") && !raiz.startsWith("//")) &&
    !/^https?:\/\//.test(raiz)
  )
    throw new Error("Usa una ruta /api o una URL HTTP/HTTPS.");
  async function solicitar(ruta, metodo = "GET", datos) {
    const control = new AbortController();
    const temporizador = setTimeout(() => control.abort(), 10000);
    try {
      const respuesta = await transporte(`${raiz}${ruta}`, {
        method: metodo,
        headers: datos
          ? { "Content-Type": "application/json", Accept: "application/json" }
          : { Accept: "application/json" },
        body: datos ? JSON.stringify(datos) : undefined,
        signal: control.signal,
      });
      const texto = await respuesta.text();
      let contenido = null;
      try {
        contenido = texto ? JSON.parse(texto) : null;
      } catch {
        throw new Error(
          "El servidor no devolvió JSON. Revisa la URL y el proxy.",
        );
      }
      if (!respuesta.ok)
        throw new ErrorApi(
          [
            contenido?.mensaje ||
              contenido?.message ||
              `Error HTTP ${respuesta.status}`,
            ...(Array.isArray(contenido?.errores) ? contenido.errores : []),
          ].join(" · "),
          respuesta.status,
        );
      return contenido;
    } catch (error) {
      if (error.name === "AbortError")
        throw new Error(
          "El servidor tardó más de 10 segundos. No repitas una creación sin consultar antes si se guardó.",
        );
      throw error;
    } finally {
      clearTimeout(temporizador);
    }
  }
  return {
    listarClientes: () => solicitar("/clientes"),
    listarVentas: () => solicitar("/ventas"),
    guardarCliente: (datos, id) =>
      solicitar(`/clientes${id ? `/${id}` : ""}`, id ? "PUT" : "POST", datos),
    guardarVenta: (datos, id) =>
      solicitar(`/ventas${id ? `/${id}` : ""}`, id ? "PUT" : "POST", datos),
    eliminar: (tipo, id) => {
      if (
        !["clientes", "ventas"].includes(tipo) ||
        !Number.isInteger(id) ||
        id < 1
      )
        throw new Error("Identificador inválido.");
      return solicitar(`/${tipo}/${id}`, "DELETE");
    },
  };
}
