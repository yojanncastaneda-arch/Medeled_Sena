import React, { useEffect, useRef } from "react";
export function Icon({ name, size = 20 }) {
  const paths = {
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1.5" />
        <rect x="14" y="3" width="7" height="7" rx="1.5" />
        <rect x="3" y="14" width="7" height="7" rx="1.5" />
        <rect x="14" y="14" width="7" height="7" rx="1.5" />
      </>
    ),
    users: (
      <>
        <circle cx="9" cy="8" r="3" />
        <path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M21 21v-3a6 6 0 0 0-3-5" />
      </>
    ),
    bag: (
      <>
        <rect x="4" y="7" width="16" height="14" rx="2" />
        <path d="M8 7V5a4 4 0 0 1 8 0v2" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M7 3v4M17 3v4M3 11h18M7 15h3M14 15h3" />
      </>
    ),
    message: (
      <path d="M21 15a3 3 0 0 1-3 3H8l-5 3V6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3z" />
    ),
    box: (
      <>
        <path d="m12 3 9 5v9l-9 5-9-5V8l9-5zM3 8l9 5 9-5M12 13v9M8 5l9 5" />
      </>
    ),
    bell: (
      <>
        <path d="M18 8a6 6 0 0 0-12 0c0 8-3 8-3 10h18c0-2-3-2-3-10M10 21h4" />
      </>
    ),
    plus: <path d="M12 5v14M5 12h14" />,
    search: (
      <>
        <circle cx="10" cy="10" r="6" />
        <path d="m15 15 6 6" />
      </>
    ),
    arrow: <path d="M4 12h16m-6-6 6 6-6 6" />,
    down: <path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4" />,
    leaf: (
      <>
        <path d="M20 3C8 2 2 7 5 15c5 6 15 0 15-12ZM4 21 16 8" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] || paths.grid}
    </svg>
  );
}

export function PageTitle({
  eyebrow = "CRM DE FIDELIZACIÓN",
  title,
  description,
  children,
}) {
  return (
    <div className="page-title">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p className="muted">{description}</p>
      </div>
      <div className="title-actions">{children}</div>
    </div>
  );
}
export function Badge({ children, tone }) {
  const className =
    tone ||
    {
      Activo: "green",
      Prospecto: "blue",
      "En prueba": "purple",
      Inactivo: "gray",
      Pendiente: "yellow",
      "En proceso": "blue",
      Resuelto: "green",
      Confirmada: "green",
    }[children] ||
    "gray";
  return <span className={`badge ${className}`}>{children}</span>;
}
export function Empty({
  title = "No hay resultados",
  text = "Prueba otros filtros o registra el primer elemento.",
}) {
  return (
    <div className="empty">
      <Icon name="search" size={30} />
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}
export function Field({ label, error, children, hint }) {
  return (
    <div className="field">
      <label>
        {label}
        {children}
      </label>
      {hint && <small>{hint}</small>}
      {error && (
        <span className="field-error" role="alert">
          {error}
        </span>
      )}
    </div>
  );
}

/** Dialogo nativo: mantiene el foco dentro y permite cerrar con Escape. */
export function Modal({ title, onClose, children, wide = false }) {
  const ref = useRef(null);
  useEffect(() => {
    const anterior = document.activeElement;
    const dialogo = ref.current;
    dialogo.showModal();
    const cerrar = (event) => {
      event.preventDefault();
      onClose();
    };
    dialogo.addEventListener("cancel", cerrar);
    return () => {
      dialogo.removeEventListener("cancel", cerrar);
      dialogo.close();
      anterior?.focus();
    };
  }, [onClose]);
  return (
    <dialog
      ref={ref}
      className={wide ? "modal wide" : "modal"}
      aria-labelledby="modal-title"
    >
      <div className="modal-head">
        <h2 id="modal-title">{title}</h2>
        <button
          className="icon-button"
          aria-label="Cerrar ventana"
          onClick={onClose}
        >
          ×
        </button>
      </div>
      {children}
    </dialog>
  );
}
