import React, { useState } from "react";
import { Icon } from "./components/UI.jsx";
import Inicio from "./pages/Inicio.jsx";
import Clientes from "./pages/Clientes.jsx";
import Ventas from "./pages/Ventas.jsx";
import Seguimiento from "./pages/Seguimiento.jsx";
import Pqrs from "./pages/Pqrs.jsx";
import Inventario from "./pages/Inventario.jsx";
import Alertas from "./pages/Alertas.jsx";
import Reportes from "./pages/Reportes.jsx";
import Api from "./pages/Api.jsx";
import { cargarDatos, guardarDatos, conActividad } from "./services/storage.js";
import { descargar } from "./services/download.js";
import { obtenerAlertas } from "./domain/model.js";
const navegacion = [
  ["inicio", "grid", "Inicio"],
  ["clientes", "users", "Clientes"],
  ["ventas", "bag", "Ventas"],
  ["seguimiento", "calendar", "Seguimiento"],
  ["pqrs", "message", "PQRS y soporte"],
  ["inventario", "box", "Inventario"],
  ["alertas", "bell", "Alertas"],
  ["reportes", "grid", "Reportes"],
  ["api", "box", "Conexión API"],
];
// Los perfiles sirven para revisar controles de presentacion, no autentican usuarios.
const permisos = {
  Gerencia: ["clientes", "ventas", "seguimiento", "pqrs", "inventario"],
  "Secretaría de gerencia": ["clientes", "seguimiento", "pqrs"],
  "Dirección comercial": ["clientes", "ventas", "seguimiento", "inventario"],
  "Dirección de proyectos": ["seguimiento", "pqrs"],
  "Gestión humana y comunicaciones": ["clientes", "seguimiento"],
  Vendedor: ["clientes", "ventas", "seguimiento"],
  "Solo consulta": [],
};
export default function App() {
  const [inicio] = useState(() => {
    try {
      return { datos: cargarDatos(), error: "" };
    } catch (e) {
      return { datos: null, error: e.message };
    }
  });
  const [datos, setDatos] = useState(inicio.datos);
  const [pagina, setPagina] = useState("inicio");
  const [rol, setRol] = useState("Gerencia");
  const [menu, setMenu] = useState(false);
  const [aviso, setAviso] = useState(null);
  function navegar(p) {
    setPagina(p);
    setMenu(false);
    setAviso(null);
    window.scrollTo(0, 0);
  }
  function actualizar(nuevos, accion, responsable) {
    try {
      const siguientes = conActividad(nuevos, accion, responsable);
      guardarDatos(siguientes);
      setDatos(siguientes);
      setAviso({ tipo: "ok", texto: "Cambios guardados en este navegador." });
      return true;
    } catch {
      setAviso({
        tipo: "error",
        texto:
          "No fue posible guardar. Revisa el espacio o permisos del navegador; no se aplicaron los cambios.",
      });
      return false;
    }
  }
  if (!datos)
    return (
      <main className="startup-error">
        <h1>No se pudieron leer los datos</h1>
        <p role="alert">{inicio.error}</p>
      </main>
    );
  const componentes = {
    inicio: Inicio,
    clientes: Clientes,
    ventas: Ventas,
    seguimiento: Seguimiento,
    pqrs: Pqrs,
    inventario: Inventario,
    alertas: Alertas,
    reportes: Reportes,
    api: Api,
  };
  const Pagina = componentes[pagina];
  const alertas = obtenerAlertas(datos);
  return (
    <div className="app-shell">
      <a className="skip-link" href="#contenido">
        Ir al contenido
      </a>
      <aside className={`sidebar ${menu ? "open" : ""}`}>
        <div className="side-brand">
          <span className="brand-mark">
            <Icon name="leaf" size={25} />
          </span>
          <div>
            <strong>
              med<span>Eled</span>
            </strong>
            <small>CRM · FIDELIZACIÓN</small>
          </div>
        </div>
        <p className="nav-label">ESPACIO DE TRABAJO</p>
        <nav aria-label="Navegación principal">
          {navegacion.map(([id, icono, nombre]) => (
            <button
              key={id}
              className={`nav-item ${pagina === id ? "active" : ""}`}
              onClick={() => navegar(id)}
              aria-current={pagina === id ? "page" : undefined}
            >
              <Icon name={icono} />
              <span>{nombre}</span>
              {id === "alertas" && alertas.length > 0 && (
                <b className="nav-count">{alertas.length}</b>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="side-tip">
            <Icon name="leaf" />
            <strong>Relaciones que crecen</strong>
            <p>Energía sostenible y atención cercana.</p>
          </div>
          <small>
            Evidencia AA4-EV03 · SENA
            <br />
            Cindy Vaneza Pineda Galeano
          </small>
        </div>
      </aside>
      {menu && (
        <button
          className="menu-backdrop"
          aria-label="Cerrar menú"
          onClick={() => setMenu(false)}
        />
      )}
      <div className="workspace">
        <header className="topbar">
          <div className="breadcrumbs">
            <button
              className="icon-button mobile-menu"
              aria-label="Abrir menú"
              aria-expanded={menu}
              onClick={() => setMenu(!menu)}
            >
              ☰
            </button>
            <span>Mi espacio</span>
            <span>/</span>
            <strong>{navegacion.find(([id]) => id === pagina)?.[2]}</strong>
          </div>
          <div className="top-actions">
            <button
              className="icon-button bell-button"
              aria-label={`Ver ${alertas.length} alertas`}
              onClick={() => navegar("alertas")}
            >
              <Icon name="bell" />
              {alertas.length > 0 && <i />}
            </button>
            <div
              className="top-logo"
              aria-label="MEDELED, marca tipográfica de referencia"
            >
              <Icon name="leaf" />
              <strong>
                med<span>Eled</span>
              </strong>
            </div>
          </div>
        </header>
        <div className="demo-bar">
          <span>
            <b>Demostración front-end</b> · Datos locales de ejemplo
          </span>
          <label>
            Perfil de revisión{" "}
            <select
              value={rol}
              onChange={(e) => {
                setRol(e.target.value);
                setAviso(null);
              }}
            >
              {Object.keys(permisos).map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </label>
        </div>
        <main id="contenido" tabIndex="-1">
          {aviso && (
            <div
              className={`toast ${aviso.tipo === "error" ? "error" : ""}`}
              role={aviso.tipo === "error" ? "alert" : "status"}
            >
              {aviso.texto}
              <button
                className="icon-button"
                aria-label="Cerrar mensaje"
                onClick={() => setAviso(null)}
              >
                ×
              </button>
            </div>
          )}
          <Pagina
            key={`${pagina}-${rol}`}
            datos={datos}
            actualizar={actualizar}
            navegar={navegar}
            puedeEditar={permisos[rol].includes(pagina)}
            responsable={rol}
          />
        </main>
        <footer className="footer">
          <span>MEDELED · CRM de fidelización de clientes</span>
          <button
            className="text-button"
            onClick={() =>
              descargar(
                "MEDELED_respaldo_local.json",
                JSON.stringify(datos, null, 2),
                "application/json",
              )
            }
          >
            Descargar respaldo local
          </button>
          <span>Hecho para acompañar.</span>
        </footer>
      </div>
    </div>
  );
}
