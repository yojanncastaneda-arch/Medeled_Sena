import test from "node:test";
import assert from "node:assert/strict";
import { crearApi, ErrorApi } from "../src/services/api.js";
const respuesta = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" },
  });
test("Contrato real de Cliente usa fechaCompra y POST", async () => {
  let llamada;
  const api = crearApi("/api", async (url, op) => {
    llamada = { url, ...op };
    return respuesta({ idCliente: 4 }, 201);
  });
  await api.guardarCliente({
    nombre: "Demo",
    producto: "LED",
    fechaCompra: "2026-09-01",
    estado: "pendiente",
  });
  assert.equal(llamada.url, "/api/clientes");
  assert.equal(llamada.method, "POST");
  assert.equal(JSON.parse(llamada.body).fechaCompra, "2026-09-01");
});
test("Venta usa PUT y precioUnitario segun DTO del repositorio", async () => {
  let llamada;
  const api = crearApi("/api/", async (url, op) => {
    llamada = { url, ...op };
    return respuesta({ idVenta: 8 });
  });
  await api.guardarVenta(
    {
      idCliente: 4,
      producto: "Panel",
      cantidad: 1,
      precioUnitario: 100,
      fechaVenta: "2026-09-01",
      estado: "pagada",
    },
    8,
  );
  assert.equal(llamada.url, "/api/ventas/8");
  assert.equal(llamada.method, "PUT");
  assert.equal(JSON.parse(llamada.body).precioUnitario, 100);
});
test("Error 409 conserva mensaje del servidor", async () => {
  const api = crearApi("/api", async () =>
    respuesta({ mensaje: "El cliente tiene ventas" }, 409),
  );
  await assert.rejects(
    api.eliminar("clientes", 3),
    (e) =>
      e instanceof ErrorApi && e.estado === 409 && e.message.includes("ventas"),
  );
});
test("Errores de validacion se muestran sin ocultar detalles", async () => {
  const api = crearApi("/api", async () =>
    respuesta(
      { mensaje: "Datos invalidos", errores: ["Producto obligatorio"] },
      400,
    ),
  );
  await assert.rejects(api.guardarCliente({}), /Producto obligatorio/);
});
test("Rechaza HTML en vez de aceptar una falsa conexion", async () => {
  const api = crearApi("/api", async () => new Response("<html>login</html>"));
  await assert.rejects(api.listarClientes(), /no devolvió JSON/);
});
test("Fallo de red no retorna datos ficticios", async () => {
  const api = crearApi("/api", async () => {
    throw new Error("Sin conexion");
  });
  await assert.rejects(api.listarVentas(), /Sin conexion/);
});
