import test from "node:test";
import assert from "node:assert/strict";
import {
  validarCliente,
  validarVenta,
  fechaValida,
  esProductoNuevo,
  crearCsv,
  normalizar,
  obtenerAlertas,
  hoy,
} from "../src/domain/model.js";
const cliente = {
  idcliente: "c1",
  nombre: "Empresa Demo",
  correo: "demo@example.com",
  telefono: "3001234567",
  estado: "Prospecto",
  tipo: "Empresa",
  origen: "Feria empresarial",
  producto: "Panel LED",
  fecha_compra: "",
  proximoContacto: "2026-12-01",
  observaciones: "",
};
test("Cliente de feria valido, sin compra previa", () =>
  assert.deepEqual(validarCliente(cliente), {}));
test("Campos obligatorios y correo invalido se rechazan", () => {
  const e = validarCliente({
    ...cliente,
    nombre: " ",
    correo: "usuario",
    telefono: "12",
    proximoContacto: "",
  });
  assert.ok(e.nombre && e.correo && e.telefono && e.proximoContacto);
});
test("Observaciones cumplen el limite real del dump 245", () =>
  assert.ok(
    validarCliente({ ...cliente, observaciones: "a".repeat(246) })
      .observaciones,
  ));
test("Venta rechaza referencias a clientes inactivos", () =>
  assert.match(
    validarVenta({ idcliente: "c1" }, [{ ...cliente, estado: "Inactivo" }]),
    /cliente/,
  ));
test("Venta valida mantiene relacion y fecha de compra", () =>
  assert.equal(
    validarVenta(
      {
        idcliente: "c1",
        producto: "Panel solar",
        cantidad: 2,
        precio_unitario: "120.50",
        fecha_venta: hoy(),
      },
      [cliente],
    ),
    "",
  ));
test("Cantidad decimal y precio fuera de DECIMAL se rechazan", () => {
  const v = {
    idcliente: "c1",
    producto: "Panel",
    cantidad: 1.5,
    precio_unitario: 12,
    fecha_venta: hoy(),
  };
  assert.match(validarVenta(v, [cliente]), /entero/);
  assert.match(
    validarVenta({ ...v, cantidad: 2, precio_unitario: 100000000 }, [cliente]),
    /precio/,
  );
});
test("Fechas imposibles no pasan", () => {
  assert.equal(fechaValida("2026-02-30"), false);
  assert.equal(fechaValida("2024-02-29"), true);
});
test("Producto nuevo dura dos meses calendario y termina en el limite", () => {
  assert.equal(esProductoNuevo("2026-01-31", "2026-03-30"), true);
  assert.equal(esProductoNuevo("2026-01-31", "2026-03-31"), false);
  assert.equal(esProductoNuevo("2026-12-01", "2026-11-17"), false);
});
test("Busqueda tolera tildes", () =>
  assert.equal(normalizar("Iluminación Pérez"), "iluminacion perez"));
test("CSV conserva caracteres y neutraliza formulas", () => {
  const csv = crearCsv([["=2+2", 'Dijo "hola"', "Cliente; Empresa"]]);
  assert.ok(csv.startsWith("\ufeff"));
  assert.ok(csv.includes("'=2+2"));
  assert.ok(csv.includes('"Dijo ""hola"""'));
});
test("Alertas omiten clientes inactivos y casos resueltos", () => {
  const a = obtenerAlertas({
    clientes: [
      { ...cliente, proximoContacto: hoy() },
      {
        ...cliente,
        idcliente: "c2",
        estado: "Inactivo",
        proximoContacto: hoy(),
      },
    ],
    casos: [
      { id: "p1", estado: "Resuelto" },
      {
        id: "p2",
        estado: "Pendiente",
        tipo: "Reclamo",
        descripcion: "Prueba",
        radicado: "PQR-2",
      },
    ],
  });
  assert.equal(a.length, 2);
  assert.equal(a[0].clase, "interna");
  assert.equal(a[1].clase, "externa");
});
