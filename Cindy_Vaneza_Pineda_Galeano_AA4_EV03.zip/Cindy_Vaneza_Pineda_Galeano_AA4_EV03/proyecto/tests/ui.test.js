/** Pruebas de interaccion en DOM simulado. No equivalen a revision visual. */
import test from "node:test";
import assert from "node:assert/strict";
import { JSDOM } from "jsdom";
import { build } from "vite";
await build({
  configFile: false,
  logLevel: "silent",
  build: {
    outDir: ".test-build",
    emptyOutDir: true,
    lib: { entry: "src/App.jsx", formats: ["es"], fileName: "app" },
    rolldownOptions: { external: ["react", "react/jsx-runtime"] },
  },
});
process.env.NODE_ENV = "test";
const dom = new JSDOM("<!doctype html><html><body></body></html>", {
  url: "http://localhost/",
});
for (const key of [
  "window",
  "document",
  "HTMLElement",
  "HTMLDialogElement",
  "localStorage",
  "MutationObserver",
  "Node",
  "Event",
  "MouseEvent",
])
  globalThis[key] = dom.window[key];
Object.defineProperty(globalThis, "navigator", {
  value: dom.window.navigator,
  configurable: true,
});
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
window.scrollTo = () => {};
HTMLDialogElement.prototype.showModal = function () {
  this.open = true;
};
HTMLDialogElement.prototype.close = function () {
  this.open = false;
};
const React = await import("react");
const { render, screen, fireEvent, within, waitFor, cleanup } =
  await import("@testing-library/react");
const { default: App } = await import("../.test-build/app.js");
const click = (nombre) =>
  fireEvent.click(screen.getByRole("button", { name: nombre, exact: true }));
const fill = (nombre, valor) =>
  fireEvent.change(screen.getByLabelText(nombre, { exact: true }), {
    target: { value: valor },
  });
const abrir = (nombre) => {
  click(nombre);
};

test("Interaccion integrada de los modulos front-end", async (t) => {
  render(React.createElement(App));
  await t.test("Panel calcula indicadores a partir de datos", () =>
    assert.ok(
      screen.getByRole("heading", { name: "Cultivamos relaciones duraderas." }),
    ),
  );
  await t.test("Formulario vacio muestra errores por campo", () => {
    abrir("Clientes");
    click("Nuevo cliente");
    fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
    assert.ok(screen.getByText("Escribe un nombre de 1 a 100 caracteres."));
  });
  await t.test("Registro y busqueda de cliente de feria", () => {
    fill("Nombre o razón social *", "Cliente de Prueba");
    fill("Correo electrónico *", "integral@example.com");
    fill("Teléfono *", "3001234567");
    fill("Producto o servicio de interés *", "Panel solar");
    fill("Origen del contacto *", "Feria empresarial");
    fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
    assert.ok(screen.getByText("Cliente de Prueba", { exact: true }));
    fireEvent.change(screen.getByRole("textbox", { name: "Buscar clientes" }), {
      target: { value: "cliente de prueba" },
    });
    assert.equal(document.querySelectorAll("tbody tr").length, 1);
  });
  await t.test("Editar conserva identificador y actualiza nombre", () => {
    click("Editar Cliente de Prueba");
    fill("Nombre o razón social *", "Cliente Actualizado");
    fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
    fireEvent.change(screen.getByRole("textbox", { name: "Buscar clientes" }), {
      target: { value: "actualizado" },
    });
    assert.ok(screen.getByText("Cliente Actualizado", { exact: true }));
  });
  await t.test("Registro de venta vinculado al cliente", () => {
    abrir("Ventas");
    click("Registrar venta");
    const id = JSON.parse(
      localStorage.getItem("medeled-aa4-ev03-v1"),
    ).clientes.find((c) => c.nombre === "Cliente Actualizado").idcliente;
    fill("Cliente *", id);
    fill("Producto o servicio *", "Panel solar");
    fill("Precio unitario (COP) *", "125000");
    fill("Cantidad *", "2");
    fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
    assert.ok(screen.getByText("Cliente Actualizado", { exact: true }));
    assert.equal(
      JSON.parse(localStorage.getItem("medeled-aa4-ev03-v1")).ventas.length,
      2,
    );
  });
  await t.test(
    "Seguimiento registra responsable, resultado y expectativa",
    () => {
      abrir("Seguimiento");
      const row = screen
        .getByText("Cliente Actualizado", { exact: true })
        .closest(".list-row");
      fireEvent.click(
        within(row).getByRole("button", { name: "Registrar contacto" }),
      );
      fill(
        "Resultado o solución dada *",
        "Se resolvió la inquietud de instalación.",
      );
      fill(
        "Expectativa acordada con el cliente *",
        "Recibir orientación de uso.",
      );
      fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
      assert.ok(screen.getByText("Se resolvió la inquietud de instalación."));
    },
  );
  await t.test("Crear PQRS y resolver conserva historial", () => {
    abrir("PQRS y soporte");
    click("Crear PQRS");
    const id = JSON.parse(localStorage.getItem("medeled-aa4-ev03-v1"))
      .clientes[0].idcliente;
    fill("Cliente *", id);
    fill("Descripción *", "Revisión de panel de prueba");
    fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
    const row = screen.getByText("Revisión de panel de prueba").closest("tr");
    fireEvent.click(within(row).getByRole("button", { name: "Ver caso" }));
    fill("Nuevo estado", "Resuelto");
    fill("Gestión realizada *", "El cliente confirmó la solución.");
    fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
    assert.ok(within(row).getByText("Resuelto"));
    assert.equal(
      JSON.parse(localStorage.getItem("medeled-aa4-ev03-v1")).casos[0].historial
        .length,
      2,
    );
  });
  await t.test("Inventario identifica producto nuevo", () => {
    abrir("Inventario");
    click("Nuevo producto");
    fill("Nombre del producto *", "Luminaria de prueba");
    fill("Cantidad *", "10");
    fireEvent.submit(screen.getByRole("dialog").querySelector("form"));
    assert.ok(
      within(screen.getByText("Luminaria de prueba").closest("tr")).getByText(
        "Nuevo · 2 meses",
      ),
    );
  });
  await t.test("Desactivar cliente conserva historial de ventas", () => {
    abrir("Clientes");
    click("Desactivar Cliente Actualizado");
    click("Confirmar desactivación");
    const row = screen
      .getByText("Cliente Actualizado", { exact: true })
      .closest("tr");
    assert.ok(within(row).getByText("Inactivo"));
    assert.equal(
      JSON.parse(localStorage.getItem("medeled-aa4-ev03-v1")).ventas.length,
      2,
    );
  });
  await t.test("Perfil de consulta oculta escritura local", () => {
    fill("Perfil de revisión", "Solo consulta");
    assert.equal(
      screen.queryByRole("button", { name: "Nuevo cliente", exact: true }),
      null,
    );
    fill("Perfil de revisión", "Gerencia");
  });
  await t.test("Datos persisten al desmontar y volver a abrir", () => {
    cleanup();
    render(React.createElement(App));
    abrir("Clientes");
    assert.ok(screen.getByText("Cliente Actualizado", { exact: true }));
  });
  await t.test("API usa contrato real sin mezclar datos locales", async () => {
    abrir("Conexión API");
    globalThis.fetch = async (url) =>
      new Response(
        JSON.stringify(
          String(url).endsWith("/clientes")
            ? [
                {
                  idCliente: 17,
                  nombre: "Cliente remoto simulado",
                  producto: "LED",
                  fechaCompra: "2026-09-01",
                  estado: "pendiente",
                },
              ]
            : [],
        ),
        { status: 200 },
      );
    click("Consultar servidor");
    await waitFor(() =>
      assert.ok(screen.getByText("#17 · Cliente remoto simulado")),
    );
    assert.equal(
      screen.queryByText("Cliente Actualizado", { exact: true }),
      null,
    );
  });
  await t.test("Error de API se muestra sin convertirlo en exito", async () => {
    globalThis.fetch = async () =>
      new Response(JSON.stringify({ mensaje: "Fallo de prueba controlado" }), {
        status: 500,
      });
    click("Consultar servidor");
    await waitFor(() =>
      assert.ok(
        screen
          .getByRole("alert")
          .textContent.includes("Fallo de prueba controlado"),
      ),
    );
  });
  cleanup();
});
