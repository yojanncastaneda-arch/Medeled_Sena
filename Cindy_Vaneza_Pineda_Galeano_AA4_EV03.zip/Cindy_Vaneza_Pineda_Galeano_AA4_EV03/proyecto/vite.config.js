import { defineConfig, loadEnv } from "vite";
// Proxy solo para desarrollo; evita requerir CORS en llamadas del mismo origen.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  return {
    base: "./",
    server: {
      proxy: {
        "/api": {
          target: env.MEDELED_API_TARGET || "http://localhost:8080",
          changeOrigin: true,
        },
      },
    },
  };
});
