@echo off
setlocal
cd /d "%~dp0proyecto"
where node >nul 2>nul
if errorlevel 1 (
 echo Instala Node.js 22.12 o superior y vuelve a ejecutar este archivo.
 pause
 exit /b 1
)
if not exist node_modules (
 call npm ci
 if errorlevel 1 (
  echo No fue posible instalar las dependencias. Revisa la conexion a internet.
  pause
  exit /b 1
 )
)
echo Abre la direccion que aparece a continuacion. Conserva esta ventana abierta.
call npm run dev
pause
