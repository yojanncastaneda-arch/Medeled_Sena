# Decisiones de implementación y compatibilidad

## Alcance elegido
Aplicación web adaptable con React. Se implementa un módulo comercial de clientes y ventas acompañado por seguimiento, PQRS e inventario de demostración. Se mantiene el enfoque de fidelización y el producto de entrega es código, no solamente un informe. No se compila ni modifica el APK Android.

## Prioridad de fuentes
1. Para solicitudes HTTP: código de DTO, modelos y controladores del repositorio `Medeled_Sena`, revisión `4d6f9eeeee63e038f866f45c8fce4b0e97027634`.
2. Para experiencia de usuario: documento de requisitos de ficha 3336209, sus RNF de color, funcionalidades e historias aportadas.
3. Para contexto: informes, documentos históricos, SQL, avances Android y evidencias EV01/EV02 de la conversación. Las últimas dos se usan como contexto de la propuesta, no como prueba de implementación anterior.

## Diferencias encontradas
| Tema | Fuentes | Decisión |
|---|---|---|
| Backend | Documentos antiguos PHP/MySQL; informe 2E Node/PostgreSQL; avance real Java/Spring/MySQL | No modificar backend. Adaptador HTTP contra los DTO Java revisados; React permanece independiente. |
| Alcance | Documento general excluye integración con inventario, mientras RF4.1/RF4.2 pide un catálogo | Incluir catálogo simple local, sin integración con sistemas externos de almacén. |
| Cliente | Directorio comercial con contacto frente a entidad API enfocada en reclamos | Mantener dos pantallas y almacenes separados. No enviar campos inexistentes a la API. |
| Fechas | Dump `fecha_compra VARCHAR(45)` y `base.sql DATE`; PDF API usa `fecha`; DTO real usa `fechaCompra` | Fechas ISO en demo, `fechaCompra` en solicitudes API. Sin alterar tablas. |
| Observaciones | Dump 245, base.sql 255 y DTO 255 | Se limita la entrada a 245 hasta unificar esquema. |
| Ventas | PDF utiliza clienteId/precio/fecha; código usa idCliente/precioUnitario/fechaVenta/producto | Se utiliza el código de DTO real, incluido producto obligatorio. |
| Colores | Verde institucional; internos azul; externos rojo; productos nuevos morado dos meses | Colores y etiquetas textuales; dos meses calendario. |
| Identidad | No se recibió un archivo de logotipo oficial | Marca tipográfica e ilustración CSS propias como referencia, en esquina superior derecha. |
| Android | Informe GA8, ZIP parcial y carpeta android del repositorio | Referencia de continuidad, separada del código web. Los enlaces USUARIO del ZIP no se usan como URL real. |

## Relación con MVC y POO
La vista corresponde a `pages` y `components`. `domain/model.js` concentra reglas puras y `services` separa persistencia y transporte. Los componentes se basan en funciones porque no necesitan herencia. Las entidades Cliente, Venta y Producto se representan con objetos de datos; las clases Java y DAO del servidor se conservan en el repositorio original.

Los diagramas completos de clases/casos de uso y el archivo Figma no estaban incluidos como archivos independientes en los adjuntos de esta entrega. Se documentan relaciones derivadas de requisitos e implementación; no se afirma haber leído o exportado diagramas ausentes. El informe 2E sí enumera Cliente, Usuario, Proyecto, Producto, Venta, Factura y Soporte. Proyecto y Factura no se codifican como módulos en esta evidencia.

## Modelo y navegación implementados
- Inicio -> Clientes -> Ficha -> historial de ventas y seguimientos.
- Cliente 1:N Venta; Cliente 1:N Seguimiento; Cliente 1:N CasoPQRS.
- Inventario consulta productos independientes; las ventas demo no descuentan existencias.
- Alertas se derivan de contactos vencidos y PQRS abiertas.
- Conexión API -> listado remoto -> crear/editar/eliminar -> recarga de listas.

## Seguridad y disponibilidad
Los perfiles de revisión solo controlan botones de la demo. No implementan autenticación. Los controladores revisados de autenticación devuelven confirmación JSON; este front-end no inventa un token que ese contrato no entrega. Toda autorización real debe comprobarse en el backend. Las credenciales SQL no forman parte del front-end.
No se garantizan aún los RNF de respuesta menor a dos segundos, HTTPS, disponibilidad 99.9% ni escalamiento de producción. Deben evaluarse con servidor, datos y red reales. No se emiten SMS/correo ni notificaciones del sistema operativo.

## Estándares aplicados
Componentes PascalCase, variables y funciones camelCase, constantes UPPER_SNAKE_CASE. Se usa separación por responsabilidad, comentarios de intención en servicios y reglas, `.editorconfig`, formato Prettier, claves estables en listas, etiquetas de formularios, diálogos accesibles y escape de texto de React. El CSV neutraliza prefijos de fórmulas y escapa comillas. Las dependencias quedan fijadas en package-lock.json.
