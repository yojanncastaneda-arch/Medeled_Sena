# Matriz de trazabilidad

Códigos tomados del documento de ficha 3336209. “Demo local” significa funcionalidad en navegador, no persistencia MySQL.

| Requisito | Comportamiento | Cobertura | Archivos |
|---|---|---|---|
| RF1.1 | Registro, consulta, edición y desactivación de clientes | Demo local | Clientes.jsx |
| RF1.2 | Crear venta vinculada a cliente | Demo local / CRUD remoto preparado | Ventas.jsx, Api.jsx |
| RF1.3 | Reporte CSV con fecha, contacto actual y compra | Demo local | Ventas.jsx |
| RF1.4 / RF1.6 | Prospectos, origen feria/contáctenos, tipo y clasificación | Demo local | Clientes.jsx |
| RF1.5 / RF2.1 / RF2.2 | Agenda, aviso por fecha y descarga de interacciones | Parcial: solo al consultar la app | Seguimiento.jsx, model.js |
| RF2.3 | Mensaje SMS/correo con fecha de visita | Pendiente de proveedor/backend | No implementado |
| RF2.4 / RF2.5 | Ticket/orden técnica con técnico y producto | Pendiente: solo radicado PQRS, no orden técnica | Pqrs.jsx implementa caso básico |
| RF2.6 / RF2.7 | Historial de visitas, materiales y mantenimientos | Parcial: resultado/expectativa de seguimiento e historial PQRS | Seguimiento.jsx, Pqrs.jsx |
| RF3.1 / RF3.2 | Crear PQRS, clasificar por tipo, cambiar estado y guardar historial | Parcial: sin convertir automáticamente a mantenimiento | Pqrs.jsx |
| RF4.1 / RF4.2 | Productos, existencias, fecha y etiqueta morada dos meses | Demo local | Inventario.jsx, model.js |
| RF5.1 / RF5.2 | Ofertas, mensajes de compra, consejos | Pendiente de comunicaciones; alertas internas sí | Alertas.jsx no envía mensajes |
| RF5.3 | Encuestas y resultados | Pendiente | No implementado |
| RF6.1 | Calendario de eventos corporativos | Pendiente: solo origen feria en cliente | Clientes.jsx |
| RNF5 | Verde, logo referencia arriba derecha, avisos azul/rojo, responsable y expectativas | Implementado como front-end; revisión visual externa pendiente | styles.css, App.jsx, Seguimiento.jsx |
| RNF1 / RNF3 / RNF4 | Menos de 2s, HTTPS, disponibilidad 99.9% | Pendiente de evaluación con despliegue real | No garantizado por demo |

## Historias de usuario utilizadas
- HU-C01: como asesor, registrar un cliente de feria y programar su contacto.
- HU-C02: como responsable comercial, consultar y editar los datos actuales sin perder compras.
- HU-V01: como vendedor, asociar una compra a un cliente existente.
- HU-S01: como responsable, documentar solución y expectativa después de un contacto.
- HU-P01: como responsable de atención, radicar una PQRS y registrar los cambios de estado.
- HU-I01: como director comercial, registrar producto con fecha y reconocer los nuevos durante dos meses.
Estas formulaciones son adaptaciones para la implementación de las historias RF01, RF03, RF04, RF05, RF10, RF23, RF25 y RF27 de los antecedentes; no sustituyen los documentos originales.
