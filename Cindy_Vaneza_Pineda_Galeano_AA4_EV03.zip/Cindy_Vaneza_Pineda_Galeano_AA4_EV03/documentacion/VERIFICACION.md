# Resultado de verificación

Se ejecutaron npm test, npm run build y npm run format:check. El registro exacto está en RESULTADOS_PRUEBAS.txt.

- 17 pruebas de reglas de datos y cliente HTTP.
- 13 escenarios de interacción en DOM simulado: panel, validación, alta/búsqueda, edición, venta, seguimiento, PQRS, producto nuevo, desactivación, perfil de consulta, persistencia, contrato API y fallo de servidor.
- El ejecutor Node cuenta también la prueba contenedora: 31 entradas aprobadas en total, 0 fallos.
- Compilación de producción correcta y formato uniforme comprobado.
- Los datos remotos utilizados en pruebas son respuestas simuladas. No hubo acceso a MySQL ni ejecución del servidor Java.
- La prueba de apertura en Chromium de este entorno no pudo ejecutarse por las restricciones del proceso del navegador; no se afirma revisión visual ni prueba móvil en navegador real. El diseño contiene reglas adaptables, pero debe comprobarse visualmente en el equipo del aprendiz con el guion siguiente.

## Comprobación manual pendiente en Chrome o Edge
1. Abrir ABRIR_DEMO.html y verificar panel sin mensajes de error. Si file:// bloquea almacenamiento, usar npm run dev.
2. Crear cliente con nombre, correo, teléfono, producto y próximo contacto; guardar, buscar, editar y recargar.
3. Registrar venta para el cliente y verificar el total en COP y el historial de su ficha.
4. Descargar CSV en Ventas y Seguimiento y revisar que los acentos y columnas sean legibles en Excel.
5. Registrar seguimiento con resultado y expectativa; confirmar responsable.
6. Crear PQRS, cambiar estado a Resuelto y revisar historial.
7. Crear producto con fecha y comprobar etiqueta morada. Quitar la fecha y comprobar que el navegador impida guardar.
8. Cambiar a Solo consulta y comprobar que no aparecen los botones de edición local.
9. Reducir ventana a 390 px: abrir menú, consultar clientes y abrir/cerrar un diálogo con Escape. La tabla puede desplazarse horizontalmente dentro de su contenedor.
10. Conectar API contra entorno de desarrollo, probar CRUD y error 409 al borrar cliente con ventas. Usar datos de prueba autorizados.
11. Confirmar el contenido publicado de la rama del repositorio antes de enviar en SENA.

Los pasos manuales son pendientes; no están marcados como aprobados.
