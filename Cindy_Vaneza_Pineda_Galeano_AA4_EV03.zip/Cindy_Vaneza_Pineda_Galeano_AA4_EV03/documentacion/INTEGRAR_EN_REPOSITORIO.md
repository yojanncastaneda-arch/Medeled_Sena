# Integración conservando el trabajo del grupo
Repositorio: https://github.com/yojanncastaneda-arch/Medeled_Sena.git

## Si ya tienes una copia del repositorio
1. Abre esa carpeta en el explorador. Debe contener `.git`, `android` y `api-proyecto` (según la revisión inspeccionada).
2. Abre una terminal dentro del repositorio y revisa `git status`. Si tienes cambios propios sin guardar, haz tu commit o conserva una copia antes de actualizar. No uses comandos de borrado ni `reset --hard`.
3. Actualiza únicamente cuando tu copia esté en condiciones de hacerlo, usando el flujo acordado con el grupo.
4. Crea una rama nueva:
```sh
git switch -c evidencia/aa4-ev03-frontend
```
5. Con el explorador, copia la carpeta `proyecto` de este paquete dentro del repositorio y renombra esa copia como `frontend-aa4-ev03`. No copies `node_modules`, `.test-build` ni la carpeta `.git` de este paquete.
6. Copia `documentacion` a una carpeta nueva `docs/aa4-ev03` y el archivo de enlace como `docs/aa4-ev03/ENLACE_REPOSITORIO.txt`.
7. Desde una terminal en `frontend-aa4-ev03`:
```sh
npm ci
npm test
npm run build
```
8. Regresa a la raíz del repositorio y registra solo las carpetas nuevas:
```sh
git add frontend-aa4-ev03 docs/aa4-ev03
git commit -m "feat: agregar front-end de fidelizacion AA4 EV03"
git push -u origin evidencia/aa4-ev03-frontend
```
9. Con la cuenta autorizada, abre una solicitud de cambios hacia la rama de trabajo del equipo. Comprueba en GitHub que aparecen los archivos antes de enviar la evidencia. No hagas push forzado ni reemplaces ramas existentes.

## Si todavía no tienes copia del repositorio
```sh
git clone https://github.com/yojanncastaneda-arch/Medeled_Sena.git
cd Medeled_Sena
```
Luego sigue desde el paso 4. Se necesita permiso del repositorio para publicar. Si GitHub no permite push, solicita acceso al administrador o usa el flujo de contribución que el grupo acuerde.

## Recuperar el historial independiente del paquete
Desde otra carpeta vacía:
```sh
git clone --branch evidencia/aa4-ev03 RUTA_AL_PAQUETE/historial-aa4-ev03.bundle medeled-aa4-ev03-local
```
El bundle conserva el historial de esta entrega; **no comparte la historia raíz del repositorio del grupo**. Para integrarlo, utiliza el procedimiento de copia anterior y crea un commit sobre la rama del equipo. El archivo `.git` está excluido del ZIP por portabilidad.
