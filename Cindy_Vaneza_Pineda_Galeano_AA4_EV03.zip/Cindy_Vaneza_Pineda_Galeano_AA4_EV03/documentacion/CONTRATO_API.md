# API del repositorio del grupo
Carpeta revisada: `api-proyecto/Medeled_cmr/Medeled_cmr/src/main/java/com/sena`.

## Cliente/reclamo
Solicitud POST `/api/clientes` o PUT `/api/clientes/{id}`:
```json
{"nombre":"Cliente de prueba","producto":"Panel LED","fechaCompra":"2026-09-01","estado":"pendiente","observaciones":"Revisar funcionamiento"}
```
La respuesta agrega `idCliente` numérico. Los estados son `pendiente`, `en_proceso` y `resuelto`. No incluye correo/teléfono/tipo de cliente. La fecha es de compra según DTO; no se renombra como fecha de reclamo. Nombre y producto admiten hasta 100 caracteres. El front limita observaciones a 245 por el dump adjunto.

## Venta
Solicitud POST `/api/ventas` o PUT `/api/ventas/{id}`:
```json
{"idCliente":1,"producto":"Panel solar","cantidad":2,"precioUnitario":85000.00,"fechaVenta":"2026-09-01","estado":"pagada"}
```
La respuesta agrega `idVenta` y `total`. Los estados son `pendiente`, `pagada` y `anulada`. Cantidad de 1 a 10000; precio con hasta 8 enteros y 2 decimales; cliente existente; fecha no futura.

## Operaciones consumidas
- GET `/api/clientes`, GET `/api/ventas`.
- POST/PUT/DELETE para ambos recursos, con confirmación de eliminación.
- El servidor también ofrece consulta por ID y ventas de un cliente; no son necesarios para la lista actual.
- 400: mostrar mensaje y errores; 404: recurso no existe; 409: conflicto, por ejemplo cliente con ventas. La UI no borra un registro localmente antes de confirmar el servidor.
- Se aceptan respuestas JSON de eliminación del código real y cuerpos vacíos 204. Un HTML inesperado se rechaza. Las solicitudes tienen un tiempo límite de 10 segundos y no se reintentan automáticamente para evitar duplicados.

## Ejecución local
1. El responsable inicia y configura Spring Boot/MySQL según su proyecto. Este paquete no inicia MySQL ni importa SQL.
2. En `proyecto`, `npm ci` y `npm run dev`.
3. La ruta `/api` se redirige desde Vite a `http://localhost:8080` por defecto. Si el backend usa otra URL, copia `.env.example` a `.env.local`, cambia `MEDELED_API_TARGET` y reinicia Vite. Debe conservarse la estructura `/api/clientes` y `/api/ventas` en el destino; un contexto WAR adicional debe contemplarse en la URL del target o en un proxy configurado por el equipo.
4. Abre Conexión API y pulsa Consultar servidor. Los datos de demostración no se transfieren.
5. Si el front se aloja en otro origen en producción, se necesita CORS configurado por el backend o un proxy del mismo origen. El proxy de Vite solo funciona durante desarrollo y no se incluye en `dist`.

Para el proyecto Tomcat/JSP existente, copia los estáticos a una subcarpeta nueva dentro de `webapp` únicamente después de revisar el contexto y la estrategia de API. No reemplaces `index.jsp`, `WEB-INF` ni la configuración del servidor. `base: './'` permite resolver los recursos relativos. La app puede verse con file:// mediante la demo autocontenida, pero esa forma no es apropiada para conectarse a la API.

## Estado de verificación
Se revisó el código del contrato y se probaron solicitudes/respuestas con transporte simulado. No se ejecutó el backend Java ni se conectó a la base de datos del grupo. Esa verificación queda pendiente antes de declarar la integración completa.
