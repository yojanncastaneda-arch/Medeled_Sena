# Fuentes consideradas
Se revisaron todos los archivos adjuntos de esta conversación y el código del repositorio indicado. El inventario JSON conserva nombre, tamaño, SHA-256 y función de cada fuente.

- Los dos PDF de requisitos de ficha 3336209 tienen el mismo SHA-256: son copias del mismo contenido.
- El informe histórico de identificación enumera RF01 a RF31; el documento actual agrupa RF1.1 a RF6.1. La trazabilidad conserva el origen de cada numeración.
- El documento “Especificacion de requisitos” y el PDF de especificación describen fidelización posventa y varias historias. Sus tablas se utilizaron como antecedentes.
- `base.sql` y `medeled_cmr_cliente.sql` tienen tipos y longitudes diferentes. No se cargaron ni reemplazaron tablas. El dump contiene DROP TABLE: no es necesario ejecutarlo para esta entrega.
- `sys_routines.sql` y `sys_sys_config.sql` corresponden al esquema de sistema sys de MySQL; no son tablas funcionales del CRM. No se agregaron al flujo de instalación ni se ejecutaron.
- El README adjunto identifica al equipo y otra evidencia; no proporciona enlace. Se utilizó el enlace explícitamente enviado después por Cindy.
- El ZIP Codigo_MedEled contiene clases Android, pruebas e instrucciones parciales, no un proyecto Gradle completo por sí solo. En el repositorio sí existe la carpeta Android; se usó como referencia, sin recompilar ni validar el APK.
- El informe 2E aporta las entidades POO y menciona otra pila tecnológica. Se registra la diferencia y no se sustituye el servidor Java real.
- Los controladores y DTO Spring Boot del repositorio determinan los campos consumidos por la pantalla Conexión API. No se incluyen credenciales, dumps de sistema ni el código Android como si fueran el nuevo front-end.

Consulta técnica: React, https://react.dev/ ; Vite, https://vite.dev/guide/ ; Git, https://git-scm.com/docs/git-bundle .
